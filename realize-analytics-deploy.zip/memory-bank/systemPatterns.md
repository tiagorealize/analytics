# System Patterns - Educational Analytics Dashboard

## Architecture Overview
The dashboard follows a modern React architecture with Next.js 14 App Router, emphasizing component composition and data flow.

## Component Architecture

### Layout Structure
```
app/
├── layout.tsx (Root layout)
├── page.tsx (Dashboard home)
├── courses/
│   └── page.tsx
├── students/
│   └── page.tsx
├── reports/
│   └── page.tsx
└── components/
    ├── layout/
    │   ├── Header.tsx
    │   ├── Sidebar.tsx
    │   └── MainLayout.tsx
    ├── dashboard/
    │   ├── KPICard.tsx
    │   ├── LineChart.tsx
    │   ├── DonutChart.tsx
    │   └── CourseRanking.tsx
    └── ui/ (ShadCN components)
```

### Data Flow Pattern
1. **Mock Data**: Centralized data store in `/lib/data`
2. **Context**: React Context for global state management
3. **Components**: Props-based data passing for local state
4. **Hooks**: Custom hooks for data fetching and calculations

## Design Patterns

### Component Composition
- **Atomic Design**: Atoms (buttons, inputs) → Molecules (cards) → Organisms (charts)
- **Compound Components**: Chart components with multiple sub-components
- **Render Props**: Flexible chart rendering with custom tooltips

### State Management
- **Local State**: useState for component-specific state
- **Context**: useReducer + Context for global app state
- **Derived State**: Computed values from raw data

### Styling Patterns
- **Utility-First**: Tailwind CSS for consistent styling
- **Component Variants**: ShadCN component variants
- **Responsive Design**: Mobile-first breakpoints
- **Dark Mode**: Prepared for future dark theme support

## Data Patterns

### Mock Data Structure
```typescript
interface Course {
  id: string;
  name: string;
  instructor: string;
  category: string;
  completionRate: number;
  avgTime: number;
  satisfaction: number;
  students: number;
}

interface Student {
  id: string;
  name: string;
  email: string;
  courses: CourseProgress[];
  totalTime: number;
  engagement: number;
}
```

### Chart Data Patterns
- **Time Series**: Array of {date, value} objects
- **Categorical**: Array of {name, value, color} objects
- **Multi-dimensional**: Complex objects with multiple metrics

## Performance Patterns
- **Code Splitting**: Route-based splitting with Next.js
- **Lazy Loading**: Dynamic imports for heavy components
- **Memoization**: React.memo for expensive calculations
- **Virtual Scrolling**: For large data tables (future enhancement)

