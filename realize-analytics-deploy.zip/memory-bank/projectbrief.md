# Project Brief - Educational Analytics Dashboard

## Project Overview
A modern, comprehensive educational analytics dashboard built with React, Next.js 14, TypeScript, and ShadCN UI. The dashboard provides educational institutions with powerful insights into course performance, student engagement, and learning analytics.

## Core Requirements

### Primary Objectives
- **Real-time Analytics**: Track course performance, student engagement, and completion rates
- **Student Progress Monitoring**: Individual student tracking with detailed progress metrics
- **Course Management**: Comprehensive course analytics with performance indicators
- **Reporting & Export**: Generate and share reports in multiple formats (PDF, CSV)
- **Insights & Recommendations**: Automated insights and performance suggestions

### Key Features
1. **Dashboard Overview**
   - KPI cards with key metrics (engagement, completion, average time)
   - Temporal evolution charts (line graphs)
   - Distribution charts (donuts) for demographics and devices
   - Course performance rankings
   - Automated insights and alerts

2. **Courses Management**
   - Course listing with advanced filtering
   - Individual course analytics
   - Performance indicators (completion rate, satisfaction, time)
   - Instructor performance tracking

3. **Students Analytics**
   - Individual student progress tracking
   - Engagement metrics per student
   - Activity history and access logs
   - Performance trends

4. **Reports & Export**
   - PDF and CSV export functionality
   - Dashboard sharing (public/private links)
   - Automated insight generation
   - Custom report builder

## Technical Stack
- **Frontend**: React 18, Next.js 14, TypeScript
- **UI Framework**: ShadCN UI, Tailwind CSS
- **Charts**: Recharts for data visualization
- **State Management**: React Context + useReducer
- **Icons**: Lucide React
- **Date Handling**: date-fns
- **Mock Data**: Custom JSON data structure

## Success Criteria
- Modern, responsive design following ShadCN patterns
- Smooth navigation between dashboard sections
- Interactive charts with hover states and tooltips
- Export functionality for reports
- Mobile-responsive layout
- Clean, maintainable code structure

