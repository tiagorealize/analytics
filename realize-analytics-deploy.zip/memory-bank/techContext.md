# Technical Context - Educational Analytics Dashboard

## Technology Stack

### Core Framework
- **Next.js 14**: React framework with App Router
- **React 18**: Latest React with concurrent features
- **TypeScript**: Type safety and better developer experience

### UI & Styling
- **ShadCN UI**: Modern component library with Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Modern icon library
- **Radix UI**: Accessible component primitives

### Data Visualization
- **Recharts**: React charting library
- **Chart Types**: Line charts, donut charts, bar charts
- **Interactivity**: Hover states, tooltips, legends

### Development Tools
- **ESLint**: Code linting with Next.js config
- **Prettier**: Code formatting
- **TypeScript**: Static type checking
- **Tailwind CSS IntelliSense**: VS Code extension

## Project Structure
```
dashboard/
├── app/                    # Next.js App Router
│   ├── globals.css        # Global styles
│   ├── layout.tsx         # Root layout
│   ├── page.tsx          # Dashboard home
│   ├── courses/          # Courses pages
│   ├── students/         # Students pages
│   └── reports/          # Reports pages
├── components/            # React components
│   ├── ui/               # ShadCN UI components
│   ├── layout/           # Layout components
│   ├── dashboard/        # Dashboard-specific components
│   └── charts/           # Chart components
├── lib/                  # Utilities and configurations
│   ├── utils.ts          # Utility functions
│   ├── data.ts           # Mock data
│   └── types.ts          # TypeScript types
├── public/               # Static assets
└── memory-bank/          # Project documentation
```

## Configuration Files
- **package.json**: Dependencies and scripts
- **tailwind.config.js**: Tailwind CSS configuration
- **tsconfig.json**: TypeScript configuration
- **next.config.js**: Next.js configuration
- **components.json**: ShadCN UI configuration

## Dependencies

### Core Dependencies
```json
{
  "next": "^14.0.0",
  "react": "^18.0.0",
  "react-dom": "^18.0.0",
  "typescript": "^5.0.0"
}
```

### UI Dependencies
```json
{
  "@radix-ui/react-*": "^1.0.0",
  "class-variance-authority": "^0.7.0",
  "clsx": "^2.0.0",
  "lucide-react": "^0.300.0",
  "tailwind-merge": "^2.0.0"
}
```

### Chart Dependencies
```json
{
  "recharts": "^2.8.0"
}
```

### Development Dependencies
```json
{
  "@types/node": "^20.0.0",
  "@types/react": "^18.0.0",
  "@types/react-dom": "^18.0.0",
  "autoprefixer": "^10.0.0",
  "eslint": "^8.0.0",
  "eslint-config-next": "^14.0.0",
  "postcss": "^8.0.0",
  "tailwindcss": "^3.0.0"
}
```

## Development Environment
- **Node.js**: Version 18+ required
- **Package Manager**: npm or yarn
- **IDE**: VS Code with recommended extensions
- **Browser**: Modern browsers with ES2020 support

## Build & Deployment
- **Build Command**: `npm run build`
- **Start Command**: `npm run start`
- **Development**: `npm run dev`
- **Linting**: `npm run lint`
- **Type Checking**: `npm run type-check`

