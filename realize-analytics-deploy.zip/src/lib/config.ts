// Google Analytics 4 Configuration
export const GA_TRACKING_ID = process.env.NEXT_PUBLIC_GA_ID || 'G-XXXXXXXXXX'

// Google Tag Manager
export const GTM_ID = process.env.NEXT_PUBLIC_GTM_ID || 'GTM-XXXXXXX'

// Facebook Pixel
export const FB_PIXEL_ID = process.env.NEXT_PUBLIC_FB_PIXEL_ID || 'XXXXXXXXXXXXXXX'

// LinkedIn Insight Tag
export const LINKEDIN_PARTNER_ID = process.env.NEXT_PUBLIC_LINKEDIN_ID || 'XXXXXXXXX'

// Hotjar
export const HOTJAR_ID = process.env.NEXT_PUBLIC_HOTJAR_ID || 'XXXXXXXXX'

// Site Configuration
export const SITE_CONFIG = {
  name: 'Realize Analytics',
  description: 'Dashboard Educacional Inteligente para gestão de cursos e acompanhamento de alunos',
  url: 'https://realize-analytics.com',
  ogImage: '/logo.svg',
  links: {
    twitter: 'https://twitter.com/realizeanalytics',
    github: 'https://github.com/realize-analytics',
    linkedin: 'https://linkedin.com/company/realize-analytics',
  },
}
