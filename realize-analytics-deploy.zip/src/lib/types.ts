export interface Unit {
  id: string
  name: string
  description: string
  duration: number // em minutos
  type: 'video' | 'text' | 'quiz' | 'assignment' | 'live'
  order: number
  isCompleted?: boolean
  progress?: number
}

export interface Module {
  id: string
  name: string
  description: string
  order: number
  units: Unit[]
  duration: number // soma das unidades
  isCompleted?: boolean
  progress?: number
}

export interface Course {
  id: string
  name: string
  instructor: string
  category: string
  completionRate: number
  avgTime: number
  satisfaction: number
  students: number
  engagement: number
  status: 'active' | 'inactive' | 'draft'
  modules: Module[]
  totalDuration: number // soma de todos os módulos
  createdAt: Date
  updatedAt: Date
}

export interface Student {
  id: string
  name: string
  email: string
  avatar?: string
  courses: CourseProgress[]
  totalTime: number
  engagement: number
  lastAccess: Date
  status: 'active' | 'inactive' | 'suspended'
}

export interface CourseProgress {
  courseId: string
  courseName: string
  progress: number
  timeSpent: number
  lastAccess: Date
  completed: boolean
  grade?: number
}

export interface KPIMetric {
  id: string
  title: string
  value: number
  change: number
  changeType: 'increase' | 'decrease'
  icon: string
  description: string
}

export interface ChartData {
  name: string
  value: number
  color?: string
}

export interface TimeSeriesData {
  date: string
  engagement: number
  completion: number
  avgTime: number
}

export interface Insight {
  id: string
  type: 'success' | 'warning' | 'info'
  title: string
  description: string
  category: 'course' | 'student' | 'general' | 'performance'
  courseId?: string
  studentId?: string
  createdAt: Date
}

export interface DashboardStats {
  totalStudents: number
  totalCourses: number
  avgEngagement: number
  avgCompletion: number
  totalRevenue: number
}
