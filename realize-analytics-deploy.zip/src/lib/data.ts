import { Course, Student, KPIMetric, ChartData, TimeSeriesData, Insight, DashboardStats, Module, Unit } from './types'

export const mockCourses: Course[] = [
  {
    id: '1',
    name: 'React Fundamentals',
    instructor: 'Maria Silva',
    category: 'Frontend',
    completionRate: 85.5,
    avgTime: 12.5,
    satisfaction: 4.8,
    students: 245,
    status: 'active',
    engagement: 88.2,
    totalDuration: 480, // 8 horas
    modules: [
      {
        id: 'm1-1',
        name: 'Introdução ao React',
        description: 'Conceitos básicos e configuração do ambiente',
        order: 1,
        duration: 120,
        progress: 95,
        isCompleted: true,
        units: [
          {
            id: 'u1-1-1',
            name: 'O que é React?',
            description: 'Introdução aos conceitos fundamentais',
            duration: 30,
            type: 'video',
            order: 1,
            isCompleted: true,
            progress: 100
          },
          {
            id: 'u1-1-2',
            name: 'Configuração do Ambiente',
            description: 'Instalação e configuração do Node.js e React',
            duration: 45,
            type: 'video',
            order: 2,
            isCompleted: true,
            progress: 100
          },
          {
            id: 'u1-1-3',
            name: 'Primeiro Componente',
            description: 'Criando seu primeiro componente React',
            duration: 45,
            type: 'assignment',
            order: 3,
            isCompleted: true,
            progress: 85
          }
        ]
      },
      {
        id: 'm1-2',
        name: 'Componentes e Props',
        description: 'Criação e reutilização de componentes',
        order: 2,
        duration: 180,
        progress: 70,
        isCompleted: false,
        units: [
          {
            id: 'u1-2-1',
            name: 'Criando Componentes',
            description: 'Como criar componentes funcionais',
            duration: 60,
            type: 'video',
            order: 1,
            isCompleted: true,
            progress: 100
          },
          {
            id: 'u1-2-2',
            name: 'Props e Estado',
            description: 'Passando dados entre componentes',
            duration: 60,
            type: 'video',
            order: 2,
            isCompleted: true,
            progress: 100
          },
          {
            id: 'u1-2-3',
            name: 'Exercício Prático',
            description: 'Criando uma lista de tarefas',
            duration: 60,
            type: 'assignment',
            order: 3,
            isCompleted: false,
            progress: 10
          }
        ]
      },
      {
        id: 'm1-3',
        name: 'Hooks e Estado',
        description: 'Gerenciamento de estado com hooks',
        order: 3,
        duration: 180,
        progress: 0,
        isCompleted: false,
        units: [
          {
            id: 'u1-3-1',
            name: 'useState Hook',
            description: 'Gerenciando estado local',
            duration: 60,
            type: 'video',
            order: 1,
            isCompleted: false,
            progress: 0
          },
          {
            id: 'u1-3-2',
            name: 'useEffect Hook',
            description: 'Efeitos colaterais e ciclo de vida',
            duration: 60,
            type: 'video',
            order: 2,
            isCompleted: false,
            progress: 0
          },
          {
            id: 'u1-3-3',
            name: 'Quiz: Hooks',
            description: 'Teste seus conhecimentos sobre hooks',
            duration: 60,
            type: 'quiz',
            order: 3,
            isCompleted: false,
            progress: 0
          }
        ]
      }
    ],
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-10-20'),
  },
  {
    id: '2',
    name: 'Node.js Backend Development',
    instructor: 'João Santos',
    category: 'Backend',
    completionRate: 78.2,
    avgTime: 18.3,
    satisfaction: 4.6,
    students: 189,
    status: 'active',
    engagement: 45.8,
    totalDuration: 600, // 10 horas
    modules: [
      {
        id: 'm2-1',
        name: 'Fundamentos do Node.js',
        description: 'Introdução ao ambiente Node.js',
        order: 1,
        duration: 180,
        progress: 60,
        isCompleted: false,
        units: [
          {
            id: 'u2-1-1',
            name: 'Instalação e Configuração',
            description: 'Configurando o ambiente Node.js',
            duration: 60,
            type: 'video',
            order: 1,
            isCompleted: true,
            progress: 100
          },
          {
            id: 'u2-1-2',
            name: 'Módulos e NPM',
            description: 'Gerenciamento de dependências',
            duration: 60,
            type: 'video',
            order: 2,
            isCompleted: true,
            progress: 100
          },
          {
            id: 'u2-1-3',
            name: 'Exercício Prático',
            description: 'Criando seu primeiro servidor',
            duration: 60,
            type: 'assignment',
            order: 3,
            isCompleted: false,
            progress: 0
          }
        ]
      },
      {
        id: 'm2-2',
        name: 'Express.js Framework',
        description: 'Criando APIs RESTful',
        order: 2,
        duration: 240,
        progress: 0,
        isCompleted: false,
        units: [
          {
            id: 'u2-2-1',
            name: 'Rotas e Middleware',
            description: 'Fundamentos do Express',
            duration: 120,
            type: 'video',
            order: 1,
            isCompleted: false,
            progress: 0
          },
          {
            id: 'u2-2-2',
            name: 'API RESTful',
            description: 'Criando endpoints REST',
            duration: 120,
            type: 'video',
            order: 2,
            isCompleted: false,
            progress: 0
          }
        ]
      }
    ],
    createdAt: new Date('2024-02-10'),
    updatedAt: new Date('2024-10-18'),
  },
  {
    id: '3',
    name: 'UI/UX Design Principles',
    instructor: 'Ana Costa',
    category: 'Design',
    completionRate: 92.1,
    avgTime: 8.7,
    satisfaction: 4.9,
    students: 156,
    status: 'active',
    engagement: 94.5, // Muito alto engajamento
    modules: [],
    totalDuration: 8.7,
    createdAt: new Date('2024-03-05'),
    updatedAt: new Date('2024-10-22'),
  },
  {
    id: '4',
    name: 'Python for Data Science',
    instructor: 'Carlos Oliveira',
    category: 'Data Science',
    completionRate: 73.8,
    avgTime: 22.1,
    satisfaction: 4.4,
    students: 312,
    status: 'active',
    engagement: 38.2, // Muito baixo engajamento
    modules: [],
    totalDuration: 22.1,
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-10-19'),
  },
  {
    id: '5',
    name: 'Mobile App Development',
    instructor: 'Fernanda Lima',
    category: 'Mobile',
    completionRate: 81.3,
    avgTime: 15.6,
    satisfaction: 4.7,
    students: 198,
    status: 'active',
    engagement: 72.6, // Engajamento médio
    modules: [],
    totalDuration: 15.6,
    createdAt: new Date('2024-04-12'),
    updatedAt: new Date('2024-10-21'),
  },
]

export const mockStudents: Student[] = [
  {
    id: '1',
    name: 'Pedro Alves',
    email: 'pedro.alves@email.com',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face',
    courses: [
      { courseId: '1', courseName: 'React Fundamentals', progress: 85, timeSpent: 10.5, lastAccess: new Date('2024-10-22'), completed: false, grade: 8.5 },
      { courseId: '2', courseName: 'Node.js Backend Development', progress: 45, timeSpent: 8.2, lastAccess: new Date('2024-10-21'), completed: false },
    ],
    totalTime: 18.7,
    engagement: 78.5,
    lastAccess: new Date('2024-10-22'),
    status: 'active',
  },
  {
    id: '2',
    name: 'Julia Mendes',
    email: 'julia.mendes@email.com',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=32&h=32&fit=crop&crop=face',
    courses: [
      { courseId: '3', courseName: 'UI/UX Design Principles', progress: 100, timeSpent: 8.7, lastAccess: new Date('2024-10-20'), completed: true, grade: 9.2 },
      { courseId: '5', courseName: 'Mobile App Development', progress: 60, timeSpent: 9.4, lastAccess: new Date('2024-10-22'), completed: false },
    ],
    totalTime: 18.1,
    engagement: 92.3,
    lastAccess: new Date('2024-10-22'),
    status: 'active',
  },
  {
    id: '3',
    name: 'Rafael Souza',
    email: 'rafael.souza@email.com',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=32&h=32&fit=crop&crop=face',
    courses: [
      { courseId: '4', courseName: 'Python for Data Science', progress: 30, timeSpent: 6.6, lastAccess: new Date('2024-10-18'), completed: false },
    ],
    totalTime: 6.6,
    engagement: 35.2,
    lastAccess: new Date('2024-10-18'),
    status: 'active',
  },
  {
    id: '4',
    name: 'Carla Santos',
    email: 'carla.santos@email.com',
    avatar: '',
    courses: [
      { courseId: '1', courseName: 'React Fundamentals', progress: 100, timeSpent: 15.2, lastAccess: new Date('2024-10-23'), completed: true, grade: 9.5 },
      { courseId: '3', courseName: 'UI/UX Design Principles', progress: 75, timeSpent: 12.3, lastAccess: new Date('2024-10-22'), completed: false },
    ],
    totalTime: 27.5,
    engagement: 88.7,
    lastAccess: new Date('2024-10-23'),
    status: 'active',
  },
  {
    id: '5',
    name: 'Bruno Costa',
    email: 'bruno.costa@email.com',
    avatar: '',
    courses: [
      { courseId: '2', courseName: 'Node.js Backend Development', progress: 20, timeSpent: 4.5, lastAccess: new Date('2024-09-15'), completed: false },
    ],
    totalTime: 4.5,
    engagement: 22.3,
    lastAccess: new Date('2024-09-15'),
    status: 'inactive',
  },
  {
    id: '6',
    name: 'Amanda Lima',
    email: 'amanda.lima@email.com',
    avatar: '',
    courses: [
      { courseId: '1', courseName: 'React Fundamentals', progress: 100, timeSpent: 14.8, lastAccess: new Date('2024-10-20'), completed: true, grade: 9.8 },
      { courseId: '2', courseName: 'Node.js Backend Development', progress: 100, timeSpent: 16.5, lastAccess: new Date('2024-10-21'), completed: true, grade: 9.3 },
      { courseId: '4', courseName: 'Python for Data Science', progress: 80, timeSpent: 11.2, lastAccess: new Date('2024-10-23'), completed: false },
    ],
    totalTime: 42.5,
    engagement: 95.2,
    lastAccess: new Date('2024-10-23'),
    status: 'active',
  },
  {
    id: '7',
    name: 'Lucas Oliveira',
    email: 'lucas.oliveira@email.com',
    avatar: '',
    courses: [
      { courseId: '5', courseName: 'Mobile App Development', progress: 10, timeSpent: 2.1, lastAccess: new Date('2024-08-30'), completed: false },
    ],
    totalTime: 2.1,
    engagement: 15.8,
    lastAccess: new Date('2024-08-30'),
    status: 'suspended',
  },
  {
    id: '8',
    name: 'Fernanda Rocha',
    email: 'fernanda.rocha@email.com',
    avatar: '',
    courses: [
      { courseId: '3', courseName: 'UI/UX Design Principles', progress: 90, timeSpent: 13.7, lastAccess: new Date('2024-10-22'), completed: false },
      { courseId: '1', courseName: 'React Fundamentals', progress: 65, timeSpent: 9.8, lastAccess: new Date('2024-10-21'), completed: false },
    ],
    totalTime: 23.5,
    engagement: 82.1,
    lastAccess: new Date('2024-10-22'),
    status: 'active',
  },
  {
    id: '9',
    name: 'Thiago Martins',
    email: 'thiago.martins@email.com',
    avatar: '',
    courses: [
      { courseId: '4', courseName: 'Python for Data Science', progress: 50, timeSpent: 11.2, lastAccess: new Date('2024-10-19'), completed: false },
    ],
    totalTime: 11.2,
    engagement: 52.4,
    lastAccess: new Date('2024-10-19'),
    status: 'active',
  },
  {
    id: '10',
    name: 'Beatriz Silva',
    email: 'beatriz.silva@email.com',
    avatar: '',
    courses: [
      { courseId: '1', courseName: 'React Fundamentals', progress: 35, timeSpent: 6.8, lastAccess: new Date('2024-09-28'), completed: false },
      { courseId: '2', courseName: 'Node.js Backend Development', progress: 25, timeSpent: 5.2, lastAccess: new Date('2024-09-25'), completed: false },
    ],
    totalTime: 12.0,
    engagement: 31.5,
    lastAccess: new Date('2024-09-28'),
    status: 'inactive',
  },
  {
    id: '11',
    name: 'Gabriel Ferreira',
    email: 'gabriel.ferreira@email.com',
    avatar: '',
    courses: [
      { courseId: '5', courseName: 'Mobile App Development', progress: 95, timeSpent: 18.3, lastAccess: new Date('2024-10-23'), completed: false },
    ],
    totalTime: 18.3,
    engagement: 91.2,
    lastAccess: new Date('2024-10-23'),
    status: 'active',
  },
  {
    id: '12',
    name: 'Patrícia Gomes',
    email: 'patricia.gomes@email.com',
    avatar: '',
    courses: [
      { courseId: '3', courseName: 'UI/UX Design Principles', progress: 15, timeSpent: 3.5, lastAccess: new Date('2024-08-15'), completed: false },
    ],
    totalTime: 3.5,
    engagement: 18.7,
    lastAccess: new Date('2024-08-15'),
    status: 'suspended',
  },
  {
    id: '13',
    name: 'Ricardo Almeida',
    email: 'ricardo.almeida@email.com',
    avatar: '',
    courses: [
      { courseId: '2', courseName: 'Node.js Backend Development', progress: 100, timeSpent: 17.8, lastAccess: new Date('2024-10-19'), completed: true, grade: 9.0 },
      { courseId: '4', courseName: 'Python for Data Science', progress: 100, timeSpent: 19.2, lastAccess: new Date('2024-10-21'), completed: true, grade: 8.8 },
    ],
    totalTime: 37.0,
    engagement: 89.5,
    lastAccess: new Date('2024-10-21'),
    status: 'active',
  },
]

export const mockKPIs: KPIMetric[] = [
  {
    id: '1',
    title: 'Total de Alunos',
    value: 1247,
    change: 12.5,
    changeType: 'increase',
    icon: 'Users',
    description: 'Alunos ativos matriculados',
  },
  {
    id: '2',
    title: 'Conclusão de Cursos',
    value: 78.3,
    change: 5.2,
    changeType: 'increase',
    icon: 'CheckCircle',
    description: 'Taxa média de conclusão',
  },
  {
    id: '3',
    title: 'Taxa de Engajamento',
    value: 84.7,
    change: -2.1,
    changeType: 'decrease',
    icon: 'TrendingUp',
    description: 'Pontuação de engajamento dos alunos',
  },
  {
    id: '4',
    title: 'Tempo Médio de Estudo',
    value: 14.2,
    change: 8.7,
    changeType: 'increase',
    icon: 'Clock',
    description: 'Horas por semana por aluno',
  },
]

export const mockTimeSeriesData: TimeSeriesData[] = [
  { date: '2024-01', engagement: 78, completion: 72, avgTime: 12.5 },
  { date: '2024-02', engagement: 82, completion: 75, avgTime: 13.2 },
  { date: '2024-03', engagement: 85, completion: 78, avgTime: 13.8 },
  { date: '2024-04', engagement: 88, completion: 81, avgTime: 14.1 },
  { date: '2024-05', engagement: 86, completion: 79, avgTime: 13.9 },
  { date: '2024-06', engagement: 84, completion: 77, avgTime: 13.6 },
  { date: '2024-07', engagement: 87, completion: 80, avgTime: 14.3 },
  { date: '2024-08', engagement: 89, completion: 82, avgTime: 14.5 },
  { date: '2024-09', engagement: 91, completion: 84, avgTime: 14.8 },
  { date: '2024-10', engagement: 88, completion: 81, avgTime: 14.2 },
]

export const mockEngagementByAge: ChartData[] = [
  { name: '18-25', value: 35, color: '#8884d8' },
  { name: '26-35', value: 42, color: '#82ca9d' },
  { name: '36-45', value: 18, color: '#ffc658' },
  { name: '46+', value: 5, color: '#ff7300' },
]

export const mockEngagementByDevice: ChartData[] = [
  { name: 'Desktop', value: 45, color: '#8884d8' },
  { name: 'Mobile', value: 38, color: '#82ca9d' },
  { name: 'Tablet', value: 17, color: '#ffc658' },
]

export const mockInsights: Insight[] = [
  {
    id: '1',
    type: 'success',
    title: 'Curso de Alto Desempenho',
    description: 'O curso Princípios de UI/UX Design apresenta 92% de taxa de conclusão, 12% acima da média',
    category: 'course',
    courseId: '3',
    createdAt: new Date('2024-10-22'),
  },
  {
    id: '2',
    type: 'warning',
    title: 'Alerta de Baixo Engajamento',
    description: 'O curso Python para Ciência de Dados teve queda de 8% no engajamento esta semana',
    category: 'course',
    courseId: '4',
    createdAt: new Date('2024-10-21'),
  },
  {
    id: '3',
    type: 'info',
    title: 'Marco do Aluno',
    description: 'Julia Mendes concluiu Princípios de UI/UX Design com nota 9,2',
    category: 'student',
    studentId: '2',
    createdAt: new Date('2024-10-20'),
  },
  {
    id: '4',
    type: 'success',
    title: 'Crescimento Geral',
    description: 'Taxa de engajamento geral aumentou 5% comparado ao mês anterior',
    category: 'general',
    createdAt: new Date('2024-10-19'),
  },
  {
    id: '5',
    type: 'warning',
    title: 'Performance Baixa',
    description: 'Rafael Souza está com engajamento abaixo de 40% há 2 semanas',
    category: 'student',
    studentId: '3',
    createdAt: new Date('2024-10-18'),
  },
  {
    id: '6',
    type: 'info',
    title: 'Tendência Positiva',
    description: 'Tempo médio de conclusão diminuiu 15% nos últimos 30 dias',
    category: 'performance',
    createdAt: new Date('2024-10-17'),
  },
]

export const mockDashboardStats: DashboardStats = {
  totalStudents: 1247,
  totalCourses: 5,
  avgEngagement: 84.7,
  avgCompletion: 78.3,
  totalRevenue: 125000,
}
