'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  ArrowLeft,
  User,
  Mail,
  Calendar,
  Clock,
  BookOpen,
  TrendingUp,
  Activity,
  Award,
  Target,
  BarChart3,
  FileText,
  Video,
  Headphones,
  Download,
  MousePointer,
  Eye,
  PlayCircle,
  PauseCircle,
  CheckCircle,
  XCircle,
  AlertCircle,
  Layers,
  Star,
  Lightbulb
} from 'lucide-react'
import { mockStudents, mockCourses } from '@/lib/data'
import { formatPercentage, formatDate } from '@/lib/utils'

interface StudentDetailsProps {
  studentId: string
}

export default function StudentDetails({ studentId }: StudentDetailsProps) {
  const router = useRouter()
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null)
  const [selectedModule, setSelectedModule] = useState<string | null>(null)
  
  const student = mockStudents.find(s => s.id === studentId)
  
  if (!student) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12 text-center">
            <User className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium mb-2">Aluno não encontrado</h3>
            <p className="text-gray-500">O aluno solicitado não existe ou foi removido.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Get enrolled courses
  const enrolledCourses = student.courses.map(sc => {
    const course = mockCourses.find(c => c.id === sc.courseId)
    return {
      ...course,
      ...sc
    }
  }).filter(Boolean)

  const selectedCourseData = selectedCourse ? 
    enrolledCourses.find(c => c.id === selectedCourse) : 
    enrolledCourses[0]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg p-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => router.push('/students')}
          className="mb-4 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar para Alunos
        </Button>

        <div className="flex items-start justify-between">
          <div className="flex items-start gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-[#CE1C5A] to-pink-600 rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-white">
                {student.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
              </span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[#1B262D]">{student.name}</h1>
              <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                <span className="flex items-center gap-1">
                  <Mail className="h-3 w-3" />
                  {student.email}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  Desde {formatDate(new Date())}
                </span>
              </div>
              <div className="mt-3">
                <Badge 
                  variant="outline" 
                  className={`
                    ${student.status === 'active' ? 'bg-green-50 text-green-700 border-green-200' : ''}
                    ${student.status === 'inactive' ? 'bg-gray-50 text-gray-700 border-gray-200' : ''}
                    ${student.status === 'suspended' ? 'bg-red-50 text-red-700 border-red-200' : ''}
                  `}
                >
                  {student.status === 'active' ? 'Ativo' : 
                   student.status === 'inactive' ? 'Inativo' : 'Suspenso'}
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Cursos Matriculados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-2xl font-bold text-[#1B262D]">{student.courses.length}</div>
              <span className="text-sm text-green-600 font-medium">
                {student.courses.filter(c => c.completed).length} concluídos
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Progresso Geral</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-2xl font-bold text-[#1B262D]">{formatPercentage(85)}</div>
              <TrendingUp className="h-4 w-4 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Engajamento</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-2xl font-bold text-[#1B262D]">{student.engagement}%</div>
              {student.engagement >= 80 ? (
                <span className="text-xs text-green-600 font-medium">Alto</span>
              ) : student.engagement >= 60 ? (
                <span className="text-xs text-amber-600 font-medium">Médio</span>
              ) : (
                <span className="text-xs text-red-600 font-medium">Baixo</span>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Tempo Total</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-2xl font-bold text-[#1B262D]">
                {Math.floor(student.totalTime / 60)}h
              </div>
              <span className="text-sm text-gray-500">
                {student.totalTime % 60}min
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Último Acesso</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-sm font-medium text-[#1B262D]">
              {formatDate(student.lastAccess)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              há {Math.floor((Date.now() - new Date(student.lastAccess).getTime()) / (1000 * 60 * 60 * 24))} dias
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Learning Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base text-[#1B262D]">Insights de Aprendizagem</CardTitle>
          <CardDescription>Padrões e recomendações personalizadas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-lg border border-gray-200 bg-green-50/30 hover:bg-green-50/50 transition-all">
              <div className="flex items-start gap-3">
                <TrendingUp className="h-5 w-5 text-green-600 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-medium text-[#1B262D] text-sm">Estilo de Aprendizagem</h4>
                  <p className="text-xs text-gray-500 mt-1">
                    Prefere conteúdo visual e exercícios práticos
                  </p>
                </div>
                <span className="text-xs text-green-700 font-medium">✓</span>
              </div>
            </div>

            <div className="p-4 rounded-lg border border-gray-200 bg-blue-50/30 hover:bg-blue-50/50 transition-all">
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-blue-600 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-medium text-[#1B262D] text-sm">Horário Ideal</h4>
                  <p className="text-xs text-gray-500 mt-1">
                    Maior produtividade entre 19h e 22h
                  </p>
                </div>
                <span className="text-xs text-blue-700 font-medium">🌙</span>
              </div>
            </div>

            <div className="p-4 rounded-lg border border-gray-200 bg-amber-50/30 hover:bg-amber-50/50 transition-all">
              <div className="flex items-start gap-3">
                <Target className="h-5 w-5 text-amber-600 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-medium text-[#1B262D] text-sm">Ponto de Atenção</h4>
                  <p className="text-xs text-gray-500 mt-1">
                    Dificuldade em módulos com muito texto
                  </p>
                </div>
                <span className="text-xs text-amber-700 font-medium">!</span>
              </div>
            </div>

            <div className="p-4 rounded-lg border border-gray-200 bg-purple-50/30 hover:bg-purple-50/50 transition-all">
              <div className="flex items-start gap-3">
                <Star className="h-5 w-5 text-purple-600 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-medium text-[#1B262D] text-sm">Força Identificada</h4>
                  <p className="text-xs text-gray-500 mt-1">
                    Excelente retenção em exercícios práticos
                  </p>
                </div>
                <span className="text-xs text-purple-700 font-medium">⭐</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Courses Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Course List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-base text-[#1B262D]">Cursos Matriculados</CardTitle>
              <CardDescription>Selecione um curso para análise detalhada</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-gray-100">
                {enrolledCourses.map((course: any) => (
                  <button
                    key={course.id}
                    onClick={() => {
                      setSelectedCourse(course.id)
                      setSelectedModule(null)
                    }}
                    className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                      selectedCourseData?.id === course.id ? 'bg-[#CE1C5A]/5 border-l-4 border-[#CE1C5A]' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <BookOpen className="h-4 w-4 text-[#CE1C5A]" />
                          <h4 className="text-sm font-medium text-[#1B262D]">{course.name}</h4>
                        </div>
                        <div className="mt-2 space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">Progresso</span>
                            <span className="text-xs font-medium text-gray-700">
                              {formatPercentage(course.progress)}
                            </span>
                          </div>
                          <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-[#CE1C5A] transition-all"
                              style={{ width: `${course.progress}%` }}
                            />
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center gap-3 text-xs text-gray-500">
                            <span className="flex items-center gap-1">
                              <Layers className="h-3 w-3" />
                              {course.modules?.length || 0} módulos
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {course.totalDuration || 0}h
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            {course.completed ? (
                              <Badge className="bg-green-100 text-green-800 text-xs">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Concluído
                              </Badge>
                            ) : (
                              <Badge className="bg-blue-100 text-blue-800 text-xs">
                                <Activity className="h-3 w-3 mr-1" />
                                Em andamento
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Course Details */}
        <div className="lg:col-span-2">
          {selectedCourseData ? (
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <BookOpen className="h-5 w-5 text-[#CE1C5A]" />
                      <CardTitle className="text-base text-[#1B262D]">
                        {selectedCourseData.name}
                      </CardTitle>
                    </div>
                    <CardDescription>Análise detalhada de interações e progresso</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => router.push(`/courses/${selectedCourseData.id}`)}
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Ver Curso
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Module Progress */}
                <div>
                  <h3 className="text-sm font-medium text-[#1B262D] mb-3">Progresso por Módulo</h3>
                  <div className="space-y-2">
                    {selectedCourseData.modules?.map((module: any) => (
                      <button
                        key={module.id}
                        onClick={() => setSelectedModule(module.id)}
                        className={`w-full p-3 rounded-lg border transition-all ${
                          selectedModule === module.id 
                            ? 'border-[#CE1C5A] bg-pink-50/30' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Layers className="h-4 w-4 text-gray-400" />
                            <div className="text-left">
                              <p className="text-sm font-medium text-[#1B262D]">{module.name}</p>
                              <p className="text-xs text-gray-500 mt-0.5">
                                {module.units.length} unidades • {module.duration}h
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-[#1B262D]">
                              {Math.round((module.completedUnits / module.units.length) * 100)}%
                            </div>
                            <div className="text-xs text-gray-500">
                              {module.completedUnits}/{module.units.length}
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Resource Interactions */}
                {selectedModule && (
                  <div>
                    <h3 className="text-sm font-medium text-[#1B262D] mb-3">Interação com Recursos</h3>
                    <div className="space-y-3">
                      {/* Videos */}
                      <div className="p-3 rounded-lg border border-gray-200">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Video className="h-4 w-4 text-blue-600" />
                            <span className="text-sm font-medium text-[#1B262D]">Vídeos</span>
                          </div>
                          <Badge variant="outline" className="text-xs">12 recursos</Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Assistidos completos</span>
                            <span className="font-medium text-gray-700">8/12 (67%)</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Tempo médio assistido</span>
                            <span className="font-medium text-gray-700">85%</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Pausas frequentes</span>
                            <span className="font-medium text-amber-600">3 vídeos</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Revisitados</span>
                            <span className="font-medium text-green-600">5 vídeos</span>
                          </div>
                        </div>
                      </div>

                      {/* Texts */}
                      <div className="p-3 rounded-lg border border-gray-200">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-green-600" />
                            <span className="text-sm font-medium text-[#1B262D]">Textos</span>
                          </div>
                          <Badge variant="outline" className="text-xs">8 recursos</Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Lidos completamente</span>
                            <span className="font-medium text-gray-700">6/8 (75%)</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Tempo médio de leitura</span>
                            <span className="font-medium text-gray-700">4:30 min</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Profundidade de scroll</span>
                            <span className="font-medium text-gray-700">92%</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Destacados/Anotações</span>
                            <span className="font-medium text-[#CE1C5A]">14</span>
                          </div>
                        </div>
                      </div>

                      {/* Interactive */}
                      <div className="p-3 rounded-lg border border-gray-200">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <MousePointer className="h-4 w-4 text-purple-600" />
                            <span className="text-sm font-medium text-[#1B262D]">Interativos</span>
                          </div>
                          <Badge variant="outline" className="text-xs">15 recursos</Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Exercícios completados</span>
                            <span className="font-medium text-gray-700">12/15 (80%)</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Taxa de acerto</span>
                            <span className="font-medium text-green-600">78%</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Tentativas médias</span>
                            <span className="font-medium text-gray-700">2.3</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Quizzes perfeitos</span>
                            <span className="font-medium text-green-600">4</span>
                          </div>
                        </div>
                      </div>

                      {/* Downloads */}
                      <div className="p-3 rounded-lg border border-gray-200">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Download className="h-4 w-4 text-amber-600" />
                            <span className="text-sm font-medium text-[#1B262D]">Downloads</span>
                          </div>
                          <Badge variant="outline" className="text-xs">6 recursos</Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Arquivos baixados</span>
                            <span className="font-medium text-gray-700">4/6 (67%)</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">PDFs</span>
                            <span className="font-medium text-gray-700">3</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Planilhas</span>
                            <span className="font-medium text-gray-700">1</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">Templates</span>
                            <span className="font-medium text-gray-700">0</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Learning Patterns */}
                <div>
                  <h3 className="text-sm font-medium text-[#1B262D] mb-3">Padrões de Aprendizagem</h3>
                  <div className="space-y-2">
                    <div className="p-3 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-[#1B262D]">Horário Preferido</p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            Maior atividade entre 19h e 22h
                          </p>
                        </div>
                        <Clock className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>

                    <div className="p-3 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-[#1B262D]">Estilo de Aprendizagem</p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            Prefere conteúdo visual e exercícios práticos
                          </p>
                        </div>
                        <Eye className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>

                    <div className="p-3 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-[#1B262D]">Velocidade</p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            Ritmo constante, média de 2 unidades por semana
                          </p>
                        </div>
                        <Activity className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>

                    <div className="p-3 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-[#1B262D]">Ponto de Atenção</p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            Dificuldade em módulos com muito texto
                          </p>
                        </div>
                        <AlertCircle className="h-4 w-4 text-amber-500" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Achievements */}
                <div>
                  <h3 className="text-sm font-medium text-[#1B262D] mb-3">Conquistas</h3>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-3 rounded-lg bg-green-50/50 border border-green-200">
                      <div className="flex items-center gap-2">
                        <Award className="h-4 w-4 text-green-600" />
                        <div>
                          <p className="text-xs font-medium text-green-900">Primeira Semana</p>
                          <p className="text-xs text-green-700">Completou 5 unidades</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-200">
                      <div className="flex items-center gap-2">
                        <Target className="h-4 w-4 text-blue-600" />
                        <div>
                          <p className="text-xs font-medium text-blue-900">Quiz Master</p>
                          <p className="text-xs text-blue-700">100% em 3 quizzes</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-purple-50/50 border border-purple-200">
                      <div className="flex items-center gap-2">
                        <BarChart3 className="h-4 w-4 text-purple-600" />
                        <div>
                          <p className="text-xs font-medium text-purple-900">Consistente</p>
                          <p className="text-xs text-purple-700">30 dias seguidos</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50/50 border border-amber-200">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-amber-600" />
                        <div>
                          <p className="text-xs font-medium text-amber-900">Módulo Expert</p>
                          <p className="text-xs text-amber-700">Completou 2 módulos</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </CardContent>
          </Card>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-medium mb-2 text-[#1B262D]">Selecione um Curso</h3>
                <p className="text-gray-500 mb-4">
                  Escolha um curso da lista ao lado para ver a análise detalhada de interações e progresso.
                </p>
                <div className="text-sm text-gray-400">
                  <p>• Análise de recursos utilizados</p>
                  <p>• Padrões de aprendizagem</p>
                  <p>• Métricas de engajamento</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
