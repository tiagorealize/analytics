'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { mockStudents } from '@/lib/data'
import { formatNumber } from '@/lib/utils'
import { Search, Users, TrendingUp, Eye, MoreHorizontal, BookOpen, Clock as ClockIcon, Award } from 'lucide-react'

export function StudentsPage() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedStatus, setSelectedStatus] = useState('all')
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const statuses = ['all', 'active', 'inactive', 'suspended']

  const filteredStudents = mockStudents.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = selectedStatus === 'all' || student.status === selectedStatus
    
    return matchesSearch && matchesStatus
  })

  // Calcular estatísticas
  const totalStudents = mockStudents.length
  const activeStudents = mockStudents.filter(s => s.status === 'active').length
  const avgEngagement = (mockStudents.reduce((acc, s) => acc + s.engagement, 0) / mockStudents.length).toFixed(1)
  const totalCompletedCourses = mockStudents.reduce((acc, s) => 
    acc + s.courses.filter(c => c.completed).length, 0
  )

  // Paginação
  const totalPages = Math.ceil(filteredStudents.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedStudents = filteredStudents.slice(startIndex, endIndex)

  // Reset para página 1 quando filtros mudam
  const handleSearchChange = (value: string) => {
    setSearchTerm(value)
    setCurrentPage(1)
  }

  const handleStatusChange = (value: string) => {
    setSelectedStatus(value)
    setCurrentPage(1)
  }

  // Sugestões para autocomplete
  const suggestions = mockStudents
    .filter(student => 
      (student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
       student.email.toLowerCase().includes(searchTerm.toLowerCase())) && 
      searchTerm.length > 0
    )
    .slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#1B262D]">Alunos</h1>
        <p className="text-gray-600 mt-1">
          Acompanhe o progresso e engajamento dos alunos
        </p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Total de Alunos
            </CardTitle>
            <Users className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStudents}</div>
            <p className="text-xs text-gray-500 mt-1">
              {activeStudents} ativos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Engajamento Médio
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#CE1C5A]">{avgEngagement}%</div>
            <p className="text-xs text-gray-500 mt-1">
              Média geral
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Cursos Concluídos
            </CardTitle>
            <Award className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{totalCompletedCourses}</div>
            <p className="text-xs text-gray-500 mt-1">
              Total de conclusões
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Média de Cursos
            </CardTitle>
            <BookOpen className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(mockStudents.reduce((acc, s) => acc + s.courses.length, 0) / mockStudents.length).toFixed(1)}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Por aluno
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Modern Search */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
        <div className="flex-1 relative">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Pesquisar alunos..."
              value={searchTerm}
              onChange={(e) => {
                handleSearchChange(e.target.value)
                setShowSuggestions(e.target.value.length > 0)
              }}
              onFocus={() => setShowSuggestions(searchTerm.length > 0)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500"
            />
          </div>
          
          {/* Autocomplete Suggestions */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto">
              {suggestions.map((student) => (
                <div
                  key={student.id}
                  onClick={() => {
                    setSearchTerm(student.name)
                    setShowSuggestions(false)
                  }}
                  className="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0 transition-colors"
                >
                  <div className="font-medium text-gray-900">{student.name}</div>
                  <div className="text-sm text-gray-500">
                    {student.email} • {student.courses.length} cursos
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
          <div className="flex gap-3">
            <select
              value={selectedStatus}
              onChange={(e) => handleStatusChange(e.target.value)}
              className="px-5 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent transition-all duration-200 text-gray-900 font-medium shadow-sm hover:border-gray-300 cursor-pointer appearance-none bg-no-repeat bg-right pr-10"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
                backgroundPosition: 'right 0.5rem center',
                backgroundSize: '1.5em 1.5em'
              }}
            >
              {statuses.map(status => (
                <option key={status} value={status}>
                  {status === 'all' ? 'Todos os Status' : 
                   status === 'active' ? 'Ativo' :
                   status === 'inactive' ? 'Inativo' : 'Suspenso'}
                </option>
              ))}
            </select>
          </div>
      </div>

      {/* Students Table */}
      <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-4 px-4 font-medium text-gray-600 text-xs uppercase">Aluno</th>
                          <th className="text-left py-4 px-4 font-medium text-gray-600 text-xs uppercase">Cursos</th>
                          <th className="text-left py-4 px-4 font-medium text-gray-600 text-xs uppercase">Progresso</th>
                          <th className="text-left py-4 px-4 font-medium text-gray-600 text-xs uppercase">Engajamento</th>
                          <th className="text-left py-4 px-4 font-medium text-gray-600 text-xs uppercase">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {paginatedStudents.map((student, index) => (
                          <tr 
                            key={student.id} 
                            className={`hover:bg-gray-100 transition-colors cursor-pointer ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}
                            onClick={() => router.push(`/students/${student.id}`)}
                          >
                            <td className="py-5 px-6">
                              <div>
                                <div className="font-semibold text-gray-900 text-base">{student.name}</div>
                                <div className="text-sm text-gray-500 mt-1">{student.email}</div>
                              </div>
                            </td>
                            <td className="py-5 px-6">
                              <div className="flex items-baseline gap-2">
                                <span className="text-lg font-semibold text-gray-900">{student.courses.length}</span>
                                <span className="text-sm text-gray-400">/</span>
                                <span className="text-base font-semibold text-green-600">
                                  {student.courses.filter(c => c.completed).length}
                                </span>
                              </div>
                              <div className="text-xs text-gray-500 mt-1">
                                total / concluídos
                              </div>
                            </td>
                            <td className="py-5 px-6">
                              <div className="flex items-center gap-2">
                                <div className="w-24 bg-gray-200 rounded-full h-2">
                                  <div 
                                    className="bg-[#CE1C5A] h-2 rounded-full" 
                                    style={{ 
                                      width: `${student.courses.reduce((acc, c) => acc + c.progress, 0) / student.courses.length}%` 
                                    }}
                                  ></div>
                                </div>
                                <span className="text-sm text-gray-600 font-semibold w-10">
                                  {Math.round(student.courses.reduce((acc, c) => acc + c.progress, 0) / student.courses.length)}%
                                </span>
                              </div>
                            </td>
                            <td className="py-5 px-6">
                              <span className={`text-base font-semibold ${
                                student.engagement >= 70 ? 'text-green-600' : 
                                student.engagement >= 50 ? 'text-yellow-600' : 'text-red-600'
                              }`}>
                                {student.engagement.toFixed(0)}%
                              </span>
                            </td>
                            <td className="py-5 px-6">
                              <Badge 
                                variant={student.status === 'active' ? 'default' : 'secondary'}
                                className="px-3 py-1 text-xs font-medium"
                              >
                                {student.status === 'active' ? 'Ativo' : 
                                 student.status === 'inactive' ? 'Inativo' : 'Suspenso'}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>

                {/* Paginação */}
                {totalPages > 1 && (
                  <div className="px-4 py-4 border-t border-gray-200">
                    <div className="flex flex-col items-center gap-3">
                      <div className="text-sm text-gray-600">
                        Mostrando {startIndex + 1} a {Math.min(endIndex, filteredStudents.length)} de {filteredStudents.length} alunos
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                          disabled={currentPage === 1}
                          className="h-8 px-3"
                        >
                          Anterior
                        </Button>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                            <Button
                              key={page}
                              variant={currentPage === page ? "default" : "outline"}
                              size="sm"
                              onClick={() => setCurrentPage(page)}
                              className={`h-8 w-8 p-0 ${currentPage === page ? 'bg-[#CE1C5A] hover:bg-[#CE1C5A]/90' : ''}`}
                            >
                              {page}
                            </Button>
                          ))}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                          disabled={currentPage === totalPages}
                          className="h-8 px-3"
                        >
                          Próxima
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
      </Card>

      {filteredStudents.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="text-gray-500">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium mb-2">Nenhum aluno encontrado</h3>
              <p>Tente ajustar os filtros ou adicionar um novo aluno.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
