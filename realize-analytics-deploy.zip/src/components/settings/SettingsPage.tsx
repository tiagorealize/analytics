'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Settings,
  Shield,
  Users,
  Bell,
  CheckCircle,
  AlertCircle,
  Clock,
  Activity,
  BarChart3,
  Mail,
  Smartphone,
  Zap,
  Lock,
  Webhook,
  Edit,
  Database,
  Globe
} from 'lucide-react'

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState('security')

  const tabs = [
    { id: 'security', name: 'Segurança', icon: Shield },
    { id: 'notifications', name: 'Notificações', icon: Bell },
    { id: 'organization', name: 'Organização', icon: Users },
    { id: 'system', name: 'Sistema', icon: Settings }
  ]


  const securitySettings = [
    {
      name: 'Autenticação Multi-Fator',
      description: 'Requer 2FA para todos os usuários administrativos',
      enabled: true,
      icon: Shield
    },
    {
      name: 'Logs de Auditoria',
      description: 'Registra todas as ações administrativas',
      enabled: true,
      icon: Activity
    },
    {
      name: 'Rate Limiting',
      description: 'Limita requisições por IP para prevenir abuso',
      enabled: true,
      icon: Zap
    },
    {
      name: 'Criptografia de Dados',
      description: 'Todos os dados sensíveis são criptografados',
      enabled: true,
      icon: Lock
    }
  ]

  const notificationChannels = [
    {
      name: 'Email',
      description: 'Notificações por email',
      icon: Mail,
      enabled: true,
      config: 'admin@empresa.com'
    },
    {
      name: 'Slack',
      description: 'Integração com Slack',
      icon: Smartphone,
      enabled: false,
      config: 'Not configured'
    },
    {
      name: 'Microsoft Teams',
      description: 'Notificações no Teams',
      icon: Smartphone,
      enabled: false,
      config: 'Not configured'
    },
    {
      name: 'Webhook',
      description: 'Notificações via webhook',
      icon: Webhook,
      enabled: true,
      config: 'https://empresa.com/webhook'
    }
  ]


  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Configurações</h1>
        <p className="text-gray-600 mt-1">
          Gerencie integrações, APIs, segurança e configurações do sistema
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-[#CE1C5A] text-[#CE1C5A]'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="h-4 w-4" />
                {tab.name}
              </button>
            )
          })}
        </nav>
      </div>

      {/* Security Tab */}
      {activeTab === 'security' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-[#CE1C5A]" />
                Configurações de Segurança
              </CardTitle>
              <CardDescription>
                Gerencie políticas de segurança e acesso
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {securitySettings.map((setting, index) => {
                  const Icon = setting.icon
                  return (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5 text-[#CE1C5A]" />
                        <div>
                          <h3 className="font-medium text-[#1B262D]">{setting.name}</h3>
                          <p className="text-sm text-gray-500">{setting.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {setting.enabled ? (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Ativo
                          </Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-800">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Inativo
                          </Badge>
                        )}
                        <Button variant="outline" size="sm">
                          Configurar
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Logs de Auditoria</CardTitle>
              <CardDescription>
                Visualize atividades recentes do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { action: 'Login realizado', user: 'admin@empresa.com', time: '14:30', ip: '192.168.1.100' },
                  { action: 'Curso criado', user: 'professor@empresa.com', time: '13:45', ip: '192.168.1.101' },
                  { action: 'Integração configurada', user: 'admin@empresa.com', time: '12:20', ip: '192.168.1.100' },
                  { action: 'Relatório exportado', user: 'analista@empresa.com', time: '11:15', ip: '192.168.1.102' }
                ].map((log, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Activity className="h-4 w-4 text-gray-400" />
                      <div>
                        <span className="font-medium text-sm">{log.action}</span>
                        <div className="text-xs text-gray-500">
                          {log.user} • {log.time} • {log.ip}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Notifications Tab */}
      {activeTab === 'notifications' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-[#CE1C5A]" />
                Canais de Notificação
              </CardTitle>
              <CardDescription>
                Configure como receber notificações do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notificationChannels.map((channel, index) => {
                  const Icon = channel.icon
                  return (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5 text-[#CE1C5A]" />
                        <div>
                          <h3 className="font-medium text-[#1B262D]">{channel.name}</h3>
                          <p className="text-sm text-gray-500">{channel.description}</p>
                          <p className="text-xs text-gray-400">{channel.config}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {channel.enabled ? (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Ativo
                          </Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-800">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Inativo
                          </Badge>
                        )}
                        <Button variant="outline" size="sm">
                          Configurar
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tipos de Notificação</CardTitle>
              <CardDescription>
                Escolha quais eventos devem gerar notificações
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-2">
                {[
                  { name: 'Novos alunos matriculados', enabled: true },
                  { name: 'Cursos com baixo engajamento', enabled: true },
                  { name: 'Falhas de sincronização', enabled: true },
                  { name: 'Relatórios prontos', enabled: false },
                  { name: 'Alertas de segurança', enabled: true },
                  { name: 'Atualizações do sistema', enabled: false }
                ].map((notification, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <span className="text-sm font-medium">{notification.name}</span>
                    <input
                      type="checkbox"
                      checked={notification.enabled}
                      className="rounded"
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Organization Tab */}
      {activeTab === 'organization' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-[#CE1C5A]" />
                Informações da Organização
              </CardTitle>
              <CardDescription>
                Configure dados da sua instituição ou empresa
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="org-name">Nome da Organização</Label>
                  <Input id="org-name" defaultValue="Universidade Exemplo" />
                </div>
                <div>
                  <Label htmlFor="org-type">Tipo</Label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent">
                    <option>Universidade</option>
                    <option>Escola</option>
                    <option>Empresa</option>
                    <option>Instituição Governamental</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="org-email">Email Principal</Label>
                  <Input id="org-email" defaultValue="contato@universidade.com" />
                </div>
                <div>
                  <Label htmlFor="org-phone">Telefone</Label>
                  <Input id="org-phone" defaultValue="+55 11 99999-9999" />
                </div>
              </div>
              
              <div>
                <Label htmlFor="org-description">Descrição</Label>
                <textarea
                  id="org-description"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent"
                  rows={3}
                  defaultValue="Instituição de ensino superior focada em tecnologia e inovação."
                />
              </div>
              
              <Button className="bg-[#CE1C5A] hover:bg-[#A0153E]">
                Salvar Alterações
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Usuários Administrativos</CardTitle>
              <CardDescription>
                Gerencie usuários com acesso administrativo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: 'João Silva', email: 'joao@universidade.com', role: 'Super Admin', lastLogin: 'Hoje' },
                  { name: 'Maria Santos', email: 'maria@universidade.com', role: 'Admin', lastLogin: 'Ontem' },
                  { name: 'Pedro Costa', email: 'pedro@universidade.com', role: 'Analista', lastLogin: '2 dias atrás' }
                ].map((user, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <div className="font-medium">{user.name}</div>
                      <div className="text-sm text-gray-500">{user.email}</div>
                      <div className="text-xs text-gray-400">Último acesso: {user.lastLogin}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">{user.role}</Badge>
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* System Tab */}
      {activeTab === 'system' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-[#CE1C5A]" />
                Status do Sistema
              </CardTitle>
              <CardDescription>
                Monitoramento em tempo real do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span className="font-medium text-green-800">API Status</span>
                  </div>
                  <p className="text-sm text-green-600">Operacional</p>
                  <p className="text-xs text-green-500 mt-1">Uptime: 99.9%</p>
                </div>
                
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Database className="h-5 w-5 text-blue-600" />
                    <span className="font-medium text-blue-800">Database</span>
                  </div>
                  <p className="text-sm text-blue-600">Conectado</p>
                  <p className="text-xs text-blue-500 mt-1">Latência: 2ms</p>
                </div>
                
                <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="h-5 w-5 text-yellow-600" />
                    <span className="font-medium text-yellow-800">Sincronização</span>
                  </div>
                  <p className="text-sm text-yellow-600">Em andamento</p>
                  <p className="text-xs text-yellow-500 mt-1">Última: 2 min atrás</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Manutenção do Sistema</CardTitle>
              <CardDescription>
                Ferramentas de manutenção e diagnóstico
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">Limpeza de Cache</h3>
                  <p className="text-sm text-gray-500 mb-3">Limpa cache do sistema para melhorar performance</p>
                  <Button variant="outline" size="sm">
                    <Zap className="h-4 w-4 mr-2" />
                    Executar
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">Backup de Dados</h3>
                  <p className="text-sm text-gray-500 mb-3">Cria backup completo dos dados</p>
                  <Button variant="outline" size="sm">
                    <Database className="h-4 w-4 mr-2" />
                    Executar
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">Teste de Integrações</h3>
                  <p className="text-sm text-gray-500 mb-3">Testa todas as integrações ativas</p>
                  <Button variant="outline" size="sm">
                    <Globe className="h-4 w-4 mr-2" />
                    Executar
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h3 className="font-medium mb-2">Logs do Sistema</h3>
                  <p className="text-sm text-gray-500 mb-3">Visualiza logs detalhados do sistema</p>
                  <Button variant="outline" size="sm">
                    <Activity className="h-4 w-4 mr-2" />
                    Visualizar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
