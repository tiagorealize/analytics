'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Download, Share, FileText, Calendar, Filter, BarChart3 } from 'lucide-react'

export function ReportsPage() {
  const [selectedPeriod, setSelectedPeriod] = useState('month')
  const [selectedFormat, setSelectedFormat] = useState('pdf')

  const reportTypes = [
    {
      id: 'overview',
      title: 'Relatório Geral',
      description: 'Visão completa do desempenho educacional',
      icon: BarChart3,
      lastGenerated: '2024-10-22',
      size: '2.4 MB'
    },
    {
      id: 'courses',
      title: 'Relatório de Cursos',
      description: 'Análise detalhada de todos os cursos',
      icon: FileText,
      lastGenerated: '2024-10-21',
      size: '1.8 MB'
    },
    {
      id: 'students',
      title: 'Relatório de Alunos',
      description: 'Progresso e engajamento dos alunos',
      icon: FileText,
      lastGenerated: '2024-10-20',
      size: '3.2 MB'
    },
    {
      id: 'engagement',
      title: 'Relatório de Engajamento',
      description: 'Métricas de engajamento e retenção',
      icon: BarChart3,
      lastGenerated: '2024-10-19',
      size: '1.5 MB'
    }
  ]

  const periods = [
    { value: 'week', label: 'Última Semana' },
    { value: 'month', label: 'Último Mês' },
    { value: 'quarter', label: 'Último Trimestre' },
    { value: 'year', label: 'Último Ano' }
  ]

  const formats = [
    { value: 'pdf', label: 'PDF' },
    { value: 'csv', label: 'CSV' },
    { value: 'excel', label: 'Excel' }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Relatórios</h1>
        <p className="text-gray-600 mt-1">
          Gere e exporte relatórios detalhados do sistema
        </p>
      </div>

      {/* Report Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Configuração de Relatório</CardTitle>
          <CardDescription>
            Configure o período e formato do relatório
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Período
              </label>
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent"
              >
                {periods.map(period => (
                  <option key={period.value} value={period.value}>
                    {period.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Formato
              </label>
              <select
                value={selectedFormat}
                onChange={(e) => setSelectedFormat(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent"
              >
                {formats.map(format => (
                  <option key={format.value} value={format.value}>
                    {format.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <Button className="w-full">
                <BarChart3 className="h-4 w-4 mr-2" />
                Gerar Relatório
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Relatórios Recentes</CardTitle>
          <CardDescription>
            Acesse relatórios gerados anteriormente
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {reportTypes.map((report) => {
              const Icon = report.icon
              return (
                <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center space-x-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#CE1C5A]/10">
                      <Icon className="h-5 w-5 text-[#CE1C5A]" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{report.title}</h3>
                      <p className="text-sm text-gray-500">{report.description}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-xs text-gray-400">
                          Gerado em: {report.lastGenerated}
                        </span>
                        <span className="text-xs text-gray-400">
                          Tamanho: {report.size}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share className="h-4 w-4 mr-2" />
                      Compartilhar
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Export Options */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Exportar Dados</CardTitle>
            <CardDescription>
              Exporte dados específicos em diferentes formatos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-medium">Dados de Cursos</h4>
                  <p className="text-sm text-gray-500">Informações completas dos cursos</p>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-medium">Dados de Alunos</h4>
                  <p className="text-sm text-gray-500">Progresso e métricas dos alunos</p>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-medium">Métricas de Engajamento</h4>
                  <p className="text-sm text-gray-500">Dados de engajamento e retenção</p>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Compartilhamento</CardTitle>
            <CardDescription>
              Compartilhe dashboards e relatórios
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Link Público</h4>
                <p className="text-sm text-gray-500 mb-3">
                  Crie um link público para compartilhar o dashboard
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  <Share className="h-4 w-4 mr-2" />
                  Gerar Link Público
                </Button>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Convite por Email</h4>
                <p className="text-sm text-gray-500 mb-3">
                  Envie convites para acessar relatórios específicos
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  Enviar Convite
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
