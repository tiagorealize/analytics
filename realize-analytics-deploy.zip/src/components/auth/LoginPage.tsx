'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight,
  CheckCircle,
  Star,
  Users,
  BarChart3,
  Shield
} from 'lucide-react'

export function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    // Simular login
    setTimeout(() => {
      setIsLoading(false)
      router.push('/')
    }, 1500)
  }

  const features = [
    {
      icon: BarChart3,
      title: 'Analytics Inteligentes',
      description: 'Insights detalhados sobre o desempenho educacional'
    },
    {
      icon: Users,
      title: 'Gestão Completa',
      description: 'Acompanhe alunos, cursos e engajamento'
    },
    {
      icon: Shield,
      title: 'Segurança Avançada',
      description: 'Proteção total dos dados educacionais'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex">
      {/* Left Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden mb-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#CE1C5A] to-[#A0153E] rounded-2xl mb-4 shadow-lg">
              <span className="text-white font-bold text-xl">R</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900">Realize</h1>
            <p className="text-slate-600 text-sm">Dashboard Educacional</p>
          </div>

          <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm">
            <CardHeader className="space-y-2 text-center pb-8">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-[#CE1C5A] to-[#A0153E] rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <span className="text-white font-bold text-2xl">R</span>
              </div>
              <CardTitle className="text-2xl font-bold text-slate-900">
                Bem-vindo de volta
              </CardTitle>
              <CardDescription className="text-slate-600">
                Entre na sua conta para acessar o dashboard
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-slate-700">
                    Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 h-12 border-slate-200 focus:border-[#CE1C5A] focus:ring-[#CE1C5A] bg-white/50 backdrop-blur-sm"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium text-slate-700">
                    Senha
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Digite sua senha"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10 h-12 border-slate-200 focus:border-[#CE1C5A] focus:ring-[#CE1C5A] bg-white/50 backdrop-blur-sm"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <input
                      id="remember"
                      type="checkbox"
                      className="w-4 h-4 text-[#CE1C5A] border-slate-300 rounded focus:ring-[#CE1C5A]"
                    />
                    <Label htmlFor="remember" className="text-sm text-slate-600">
                      Lembrar de mim
                    </Label>
                  </div>
                  <button
                    type="button"
                    className="text-sm text-[#CE1C5A] hover:text-[#A0153E] font-medium transition-colors"
                  >
                    Esqueceu a senha?
                  </button>
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-[#CE1C5A] to-[#A0153E] hover:from-[#A0153E] hover:to-[#8B1235] text-white font-medium shadow-lg hover:shadow-xl transition-all duration-200"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Entrando...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      Entrar
                      <ArrowRight className="h-4 w-4" />
                    </div>
                  )}
                </Button>
              </form>

              <div className="mt-8 text-center">
                <p className="text-sm text-slate-600">
                  Não tem uma conta?{' '}
                  <button className="text-[#CE1C5A] hover:text-[#A0153E] font-medium transition-colors">
                    Solicite acesso
                  </button>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Demo Credentials */}
          <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
            <h3 className="text-sm font-medium text-blue-900 mb-2">Credenciais de Demonstração:</h3>
            <div className="text-xs text-blue-700 space-y-1">
              <p><strong>Email:</strong> admin@realize.com</p>
              <p><strong>Senha:</strong> demo123</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Logo and Features */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#CE1C5A] via-[#A0153E] to-[#8B1235] p-12 flex-col justify-center relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-32 h-32 bg-white rounded-full"></div>
          <div className="absolute top-40 right-20 w-24 h-24 bg-white rounded-full"></div>
          <div className="absolute bottom-20 left-40 w-40 h-40 bg-white rounded-full"></div>
          <div className="absolute bottom-40 right-40 w-20 h-20 bg-white rounded-full"></div>
        </div>
        
        <div className="relative z-10 max-w-md mx-auto text-center">
          {/* Logo */}
          <div className="mb-12">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-white/20 backdrop-blur-sm rounded-3xl mb-6 shadow-2xl">
              <span className="text-white font-bold text-4xl">R</span>
            </div>
            <h1 className="text-5xl font-bold text-white mb-4">Realize</h1>
            <p className="text-white/90 text-xl leading-relaxed">
              Dashboard Educacional Inteligente
            </p>
          </div>
          
          {/* Features */}
          <div className="space-y-8">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <div key={index} className="flex items-start gap-4 text-left">
                  <div className="flex-shrink-0 w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-lg">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg mb-1">{feature.title}</h3>
                    <p className="text-white/80 text-sm leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              )
            })}
          </div>
          
          {/* Trust Indicators */}
          <div className="mt-12 pt-8 border-t border-white/20">
            <div className="flex items-center justify-center gap-6 text-white/80 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                <span>Seguro</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="h-4 w-4" />
                <span>Confiável</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                <span>Protegido</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
