'use client'

import { usePathname } from 'next/navigation'
import { MainLayout } from './MainLayout'

interface ConditionalLayoutProps {
  children: React.ReactNode
}

export function ConditionalLayout({ children }: ConditionalLayoutProps) {
  const pathname = usePathname()
  
  // Páginas que não devem usar o MainLayout
  const noLayoutPages = ['/login']
  
  if (noLayoutPages.includes(pathname)) {
    return <>{children}</>
  }
  
  return <MainLayout>{children}</MainLayout>
}
