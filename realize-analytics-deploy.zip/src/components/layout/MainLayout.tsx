'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { 
  LayoutDashboard, 
  BookOpen, 
  Users, 
  FileText,
  Settings,
  Menu,
  X,
  User,
  LogOut
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const navigation = [
  { name: 'Visão Geral', href: '/', icon: LayoutDashboard },
  { name: 'Cursos', href: '/courses', icon: BookOpen },
  { name: 'Alunos', href: '/students', icon: Users },
  { name: 'Relatórios', href: '/reports', icon: FileText },
  { name: 'Configurações', href: '/settings', icon: Settings },
]

export function MainLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const pathname = usePathname()

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Mobile sidebar */}
      <div className={cn(
        "fixed inset-0 z-50 lg:hidden",
        sidebarOpen ? "block" : "hidden"
      )}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setSidebarOpen(false)} />
        <div className="relative flex w-72 flex-col bg-white shadow-xl">
          <div className="flex h-20 items-center justify-between px-6">
            <div className="flex items-center w-full">
              <div className="flex h-16 w-full items-center justify-start">
                <Image
                  src="/logo.svg"
                  alt="Logo"
                  width={240}
                  height={60}
                  className="object-contain w-[80%] h-auto"
                />
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(false)}
              className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            >
              <X className="h-6 w-6" />
            </Button>
          </div>
          <nav className="flex-1 px-6 py-4">
            <ul className="space-y-2">
              {navigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <li key={item.name}>
                    <Link
                      href={item.href}
                      onClick={() => setSidebarOpen(false)}
                      className={cn(
                        "flex items-center rounded-xl px-4 py-4 text-sm font-medium transition-all duration-200 group",
                        isActive
                          ? "bg-[#CE1C5A] text-white shadow-sm"
                          : "text-gray-700 hover:bg-white hover:text-[#CE1C5A] hover:shadow-sm"
                      )}
                    >
                      <item.icon className={cn(
                        "mr-4 h-5 w-5 transition-colors",
                        isActive ? "text-white" : "text-gray-500 group-hover:text-[#CE1C5A]"
                      )} />
                      <span className="font-semibold">{item.name}</span>
                    </Link>
                  </li>
                )
              })}
            </ul>
            
            {/* User Profile & Logout */}
            <div className="mt-8 pt-4 border-t border-gray-200 space-y-4">
              {/* User Profile */}
              <div className="px-4 py-3 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#CE1C5A] to-[#CE1C5A]/80 flex items-center justify-center shadow-sm">
                    <User className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 truncate">Admin User</p>
                    <p className="text-xs text-gray-500 truncate">admin@realize.com</p>
                  </div>
                </div>
              </div>
              
              {/* Logout Button */}
              <button
                onClick={() => {
                  // Handle logout
                  console.log('Logout')
                }}
                className="w-full flex items-center rounded-xl px-4 py-4 text-sm font-medium text-red-600 hover:bg-red-50 hover:text-red-700 transition-all duration-200 group"
              >
                <LogOut className="mr-4 h-5 w-5" />
                <span className="font-semibold">Sair</span>
              </button>
            </div>
          </nav>
        </div>
      </div>

      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-72 lg:flex-col">
        <div className="flex grow flex-col gap-y-8 overflow-y-auto pl-8 py-6">
          <div className="flex h-20 items-center pr-8">
            <div className="flex items-center w-full">
              <Image
                src="/logo.svg"
                alt="Logo"
                width={240}
                height={60}
                className="object-contain w-[80%] h-auto"
              />
            </div>
          </div>
          <nav className="flex flex-1 flex-col">
            <ul className="flex flex-1 flex-col gap-y-2">
              <li>
                <ul className="space-y-2">
                  {navigation.map((item) => {
                    const isActive = pathname === item.href
                    return (
                      <li key={item.name}>
                        <Link
                          href={item.href}
                          className={cn(
                            "flex items-center rounded-xl px-4 py-4 text-sm font-medium transition-all duration-200 group",
                            isActive
                              ? "bg-[#CE1C5A] text-white shadow-sm"
                              : "text-gray-700 hover:bg-white hover:text-[#CE1C5A] hover:shadow-sm"
                          )}
                        >
                          <item.icon className={cn(
                            "mr-4 h-5 w-5 transition-colors",
                            isActive ? "text-white" : "text-gray-500 group-hover:text-[#CE1C5A]"
                          )} />
                          <span className="font-semibold">{item.name}</span>
                        </Link>
                      </li>
                    )
                  })}
                </ul>
              </li>
            </ul>
            
            {/* User Profile & Logout */}
            <div className="mt-auto pt-4 border-t border-gray-200 space-y-4">
              {/* User Profile */}
              <div className="px-4 py-3 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#CE1C5A] to-[#CE1C5A]/80 flex items-center justify-center shadow-sm">
                    <User className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 truncate">Admin User</p>
                    <p className="text-xs text-gray-500 truncate">admin@realize.com</p>
                  </div>
                </div>
              </div>
              
              {/* Logout Button */}
              <button
                onClick={() => {
                  // Handle logout
                  console.log('Logout')
                }}
                className="w-full flex items-center rounded-xl px-4 py-4 text-sm font-medium text-red-600 hover:bg-red-50 hover:text-red-700 transition-all duration-200 group"
              >
                <LogOut className="mr-4 h-5 w-5" />
                <span className="font-semibold">Sair</span>
              </button>
            </div>
          </nav>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-72">
        {/* Mobile menu button */}
        <div className="lg:hidden sticky top-0 z-40 flex h-16 items-center bg-white border-b border-gray-200 px-4 shadow-sm">
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>

        {/* Page content */}
        <main className="py-6 bg-gray-100 min-h-screen">
          <div className="mx-auto max-w-none px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 min-h-[calc(100vh-3rem)]">
              <div className="p-6 lg:p-8 xl:p-10">
                {children}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
