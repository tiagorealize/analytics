'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { mockTimeSeriesData } from '@/lib/data'

// Dados por meses
const monthlyData = [
  { month: 'Jan', engagement: 78, completion: 72, avgTime: 12.5 },
  { month: 'Fev', engagement: 82, completion: 75, avgTime: 11.8 },
  { month: 'Mar', engagement: 85, completion: 78, avgTime: 11.2 },
  { month: 'Abr', engagement: 88, completion: 81, avgTime: 10.9 },
  { month: 'Mai', engagement: 84, completion: 79, avgTime: 11.5 },
  { month: 'Jun', engagement: 87, completion: 83, avgTime: 10.7 },
  { month: 'Jul', engagement: 90, completion: 85, avgTime: 10.3 },
  { month: 'Ago', engagement: 86, completion: 82, avgTime: 11.1 },
  { month: 'Set', engagement: 89, completion: 84, avgTime: 10.8 },
  { month: 'Out', engagement: 92, completion: 87, avgTime: 10.1 },
  { month: 'Nov', engagement: 88, completion: 85, avgTime: 10.6 },
  { month: 'Dez', engagement: 91, completion: 88, avgTime: 9.9 },
]

        // Dados por semanas (últimas 12 semanas) - apenas engajamento
        const weeklyData = [
          { week: 'Sem 1', engagement: 85 },
          { week: 'Sem 2', engagement: 87 },
          { week: 'Sem 3', engagement: 83 },
          { week: 'Sem 4', engagement: 89 },
          { week: 'Sem 5', engagement: 86 },
          { week: 'Sem 6', engagement: 91 },
          { week: 'Sem 7', engagement: 88 },
          { week: 'Sem 8', engagement: 84 },
          { week: 'Sem 9', engagement: 90 },
          { week: 'Sem 10', engagement: 87 },
          { week: 'Sem 11', engagement: 92 },
          { week: 'Sem 12', engagement: 89 },
        ]

        // Dados por trimestres
        const quarterlyData = [
          { quarter: 'Q1 2024', engagement: 82, completion: 76, avgTime: 11.8 },
          { quarter: 'Q2 2024', engagement: 85, completion: 79, avgTime: 11.2 },
          { quarter: 'Q3 2024', engagement: 88, completion: 82, avgTime: 10.9 },
          { quarter: 'Q4 2024', engagement: 91, completion: 85, avgTime: 10.5 },
        ]

        // Dados por semestres
        const semesterData = [
          { semester: '1º Sem 2024', engagement: 83, completion: 77, avgTime: 11.5 },
          { semester: '2º Sem 2024', engagement: 89, completion: 83, avgTime: 10.7 },
        ]

        // Dados por anos (últimos 3 anos)
        const yearlyData = [
          { year: '2022', engagement: 75, completion: 68, avgTime: 13.2 },
          { year: '2023', engagement: 82, completion: 76, avgTime: 11.8 },
          { year: '2024', engagement: 88, completion: 84, avgTime: 10.6 },
        ]

export function AnalyticsChart() {
  const [selectedPeriod, setSelectedPeriod] = useState('month')

  const getData = () => {
    switch (selectedPeriod) {
      case 'week':
        return weeklyData
      case 'quarter':
        return quarterlyData
      case 'semester':
        return semesterData
      case 'year':
        return yearlyData
      default:
        return monthlyData
    }
  }

  const getXAxisKey = () => {
    switch (selectedPeriod) {
      case 'week':
        return 'week'
      case 'quarter':
        return 'quarter'
      case 'semester':
        return 'semester'
      case 'year':
        return 'year'
      default:
        return 'month'
    }
  }

  const getTooltipLabel = () => {
    switch (selectedPeriod) {
      case 'week':
        return 'Semana'
      case 'quarter':
        return 'Trimestre'
      case 'semester':
        return 'Semestre'
      case 'year':
        return 'Ano'
      default:
        return 'Mês'
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Visão Geral Analítica</CardTitle>
            <CardDescription>
              Evolução temporal de engajamento, conclusão e tempo médio
            </CardDescription>
          </div>
          <div className="flex items-center space-x-2">
                    <select
                      value={selectedPeriod}
                      onChange={(e) => setSelectedPeriod(e.target.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent text-sm"
                    >
                      <option value="week">Semana</option>
                      <option value="month">Mês</option>
                      <option value="quarter">Trimestre</option>
                      <option value="semester">Semestre</option>
                      <option value="year">Ano</option>
                    </select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={getData()}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey={getXAxisKey()} 
                tick={{ fontSize: 10 }}
              />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip 
                labelFormatter={(value) => `${getTooltipLabel()}: ${value}`}
                formatter={(value, name) => [
                  name === 'engagement' ? `${value}%` : 
                  name === 'completion' ? `${value}%` : 
                  `${value}h`,
                  name === 'engagement' ? 'Engajamento' :
                  name === 'completion' ? 'Conclusão' :
                  'Tempo Médio'
                ]}
                contentStyle={{
                  fontSize: '12px',
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Legend 
                wrapperStyle={{
                  paddingTop: '20px',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#6B7280'
                }}
                iconType="line"
                iconSize={8}
              />
                      <Line 
                        type="monotone" 
                        dataKey="engagement" 
                        stroke="#CE1C5A" 
                        strokeWidth={2}
                        name="Engajamento"
                        dot={{ fill: '#CE1C5A', strokeWidth: 1, r: 3 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="completion" 
                        stroke="#10B981" 
                        strokeWidth={2}
                        name="Conclusão"
                        dot={{ fill: '#10B981', strokeWidth: 1, r: 3 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="avgTime" 
                        stroke="#F59E0B" 
                        strokeWidth={2}
                        name="Tempo Médio"
                        dot={{ fill: '#F59E0B', strokeWidth: 1, r: 3 }}
                      />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
