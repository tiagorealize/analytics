'use client'

import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { mockCourses } from '@/lib/data'
import { formatPercentage } from '@/lib/utils'
import { Users, Clock, CheckCircle } from 'lucide-react'

export function CourseRanking() {
  const router = useRouter()
  const sortedCourses = [...mockCourses].sort((a, b) => b.completionRate - a.completionRate)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ranking de Cursos</CardTitle>
        <CardDescription>
          Cursos com melhor desempenho por taxa de conclusão
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {sortedCourses.map((course, index) => (
            <div 
              key={course.id} 
              className="flex items-center justify-between py-3 px-2 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
              onClick={() => router.push(`/courses/${course.id}`)}
            >
              <div className="flex items-center space-x-4">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#CE1C5A]/10 text-[#CE1C5A] font-semibold text-xs">
                  {index + 1}
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 text-base">{course.name}</h4>
                  <p className="text-sm text-gray-500">{course.instructor}</p>
                </div>
              </div>
              <div className="flex items-center space-x-6 text-sm text-gray-600">
                <div className="flex items-center">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  {formatPercentage(course.completionRate)}
                </div>
                <div className="flex items-center">
                  <Users className="h-3 w-3 mr-1" />
                  {course.students}
                </div>
                <div className="flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  {course.avgTime}h
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
