'use client'

import { KPIGrid } from './KPICard'
import { AnalyticsChart } from './AnalyticsChart'
import { EngagementByAge, EngagementByDevice } from './EngagementCharts'
import { CourseRanking } from './CourseRanking'
import { InsightsCard } from './InsightsCard'

export function DashboardOverview() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#1B262D]">Visão Geral</h1>
        <p className="text-gray-600 mt-1">
          Visão geral do desempenho educacional e métricas de engajamento
        </p>
      </div>

      {/* KPI Cards */}
      <KPIGrid />

      {/* Analytics Chart */}
      <AnalyticsChart />

      {/* Engagement Charts Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        <EngagementByAge />
        <EngagementByDevice />
      </div>

      {/* Bottom Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        <CourseRanking />
        <InsightsCard />
      </div>
    </div>
  )
}
