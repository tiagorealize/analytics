'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Users, CheckCircle, TrendingUp, Clock, ArrowUp, ArrowDown } from 'lucide-react'
import { mockKPIs } from '@/lib/data'
import { formatNumber, formatPercentage } from '@/lib/utils'

const iconMap = {
  Users,
  CheckCircle,
  TrendingUp,
  Clock,
}

export function KPICard({ kpi }: { kpi: typeof mockKPIs[0] }) {
  const Icon = iconMap[kpi.icon as keyof typeof iconMap]
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-[#1B262D]">
          {kpi.title}
        </CardTitle>
        <Icon className="h-4 w-4 text-gray-400" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {kpi.title === 'Conclusão de Cursos' || kpi.title === 'Taxa de Engajamento' 
            ? formatPercentage(kpi.value)
            : kpi.title === 'Tempo Médio de Estudo'
            ? `${kpi.value}h`
            : formatNumber(kpi.value)
          }
        </div>
        <div className="flex items-center space-x-2 text-xs text-gray-500">
          {kpi.changeType === 'increase' ? (
            <ArrowUp className="h-3 w-3 text-green-500" />
          ) : (
            <ArrowDown className="h-3 w-3 text-red-500" />
          )}
          <span className={kpi.changeType === 'increase' ? 'text-green-500' : 'text-red-500'}>
            {formatPercentage(Math.abs(kpi.change))}
          </span>
          <span>vs mês anterior</span>
        </div>
        <p className="text-xs text-gray-500 mt-1">{kpi.description}</p>
      </CardContent>
    </Card>
  )
}

export function KPIGrid() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {mockKPIs.map((kpi) => (
        <KPICard key={kpi.id} kpi={kpi} />
      ))}
    </div>
  )
}
