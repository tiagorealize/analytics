'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { mockInsights } from '@/lib/data'
import { CheckCircle, AlertTriangle, Info, TrendingUp, Filter } from 'lucide-react'
import { formatDate } from '@/lib/utils'

const iconMap = {
  success: CheckCircle,
  warning: AlertTriangle,
  info: Info,
}

const colorMap = {
  success: 'text-green-600 bg-green-50',
  warning: 'text-yellow-600 bg-yellow-50',
  info: 'text-[#CE1C5A] bg-[#CE1C5A]/10',
}

const categoryMap = {
  course: 'Cursos',
  student: 'Alunos',
  general: 'Geral',
  performance: 'Performance',
}

export function InsightsCard() {
  const [selectedCategory, setSelectedCategory] = useState('all')

  const filteredInsights = mockInsights.filter(insight => 
    selectedCategory === 'all' || insight.category === selectedCategory
  )

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Insights Automáticos</CardTitle>
            <CardDescription>
              Análises e recomendações baseadas nos dados
            </CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-500" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent text-sm"
            >
              <option value="all">Todas as Áreas</option>
              <option value="course">Cursos</option>
              <option value="student">Alunos</option>
              <option value="general">Geral</option>
              <option value="performance">Performance</option>
            </select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {filteredInsights.map((insight) => {
            const Icon = iconMap[insight.type]
            const colorClass = colorMap[insight.type]
            
            return (
              <div key={insight.id} className="flex items-start space-x-3 py-3 px-2 hover:bg-gray-50 rounded-lg transition-colors">
                <div className={`flex h-5 w-5 items-center justify-center rounded-full ${colorClass} flex-shrink-0`}>
                  <Icon className="h-3 w-3" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-medium text-gray-900 text-base">{insight.title}</h4>
                    <Badge variant="outline" className="text-xs px-2 py-0">
                      {insight.type === 'success' ? 'Sucesso' : 
                       insight.type === 'warning' ? 'Atenção' : 'Informação'}
                    </Badge>
                    <Badge variant="secondary" className="text-xs px-2 py-0">
                      {categoryMap[insight.category]}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{insight.description}</p>
                  <span className="text-sm text-gray-500 mt-1 block">
                    {formatDate(insight.createdAt)}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
