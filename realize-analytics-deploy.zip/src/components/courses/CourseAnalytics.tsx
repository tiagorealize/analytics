'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  ArrowLeft,
  ArrowRight, 
  BookOpen, 
  Users, 
  Clock, 
  TrendingUp, 
  Star, 
  CheckCircle,
  Calendar,
  Target,
  Activity,
  ArrowUp,
  ArrowDown
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { formatPercentage, formatNumber } from '@/lib/utils'
import { mockCourses, mockStudents } from '@/lib/data'
import { CourseStructure } from './CourseStructure'

interface CourseAnalyticsProps {
  courseId: string
}

export default function CourseAnalytics({ courseId }: CourseAnalyticsProps) {
  const [selectedPeriod, setSelectedPeriod] = useState('30d')
  const course = mockCourses.find(c => c.id === courseId)

  if (!course) {
    return (
      <div className="space-y-6">
        <div className="p-6">
          <Card>
            <CardContent className="p-12 text-center">
              <div className="text-gray-500">
                <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-medium mb-2">Curso não encontrado</h3>
                <p>O curso solicitado não existe ou foi removido.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Get top students for this course
  const topStudents = mockStudents
    .filter(student => student.courses.some(c => c.courseId === course.id))
    .sort((a, b) => {
      const aProgress = a.courses.find(c => c.courseId === course.id)?.progress || 0
      const bProgress = b.courses.find(c => c.courseId === course.id)?.progress || 0
      return bProgress - aProgress
    })
    .slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => window.history.back()}
          className="hover:bg-gray-100"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
        
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-[#1B262D]">{course.name}</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant={course.status === 'active' ? 'default' : 'secondary'}>
              {course.status === 'active' ? 'Ativo' : 'Inativo'}
            </Badge>
            <Button variant="outline" size="sm">
              <Calendar className="h-4 w-4 mr-2" />
              Última atualização: {new Date().toLocaleDateString('pt-BR')}
            </Button>
          </div>
        </div>
      </div>

      {/* Course Structure */}
      <CourseStructure course={course} />

      {/* Course Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Total de Alunos
            </CardTitle>
            <Users className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatNumber(course.students)}
            </div>
            <div className="flex items-center space-x-2 text-xs text-gray-500">
              <ArrowUp className="h-3 w-3 text-green-500" />
              <span className="text-green-500">
                {formatPercentage(12.5)}
              </span>
              <span>vs mês anterior</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">Alunos matriculados no curso</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Taxa de Conclusão
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatPercentage(course.completionRate)}
            </div>
            <p className="text-xs text-gray-500">
              Taxa média de conclusão
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Tempo Médio
            </CardTitle>
            <Clock className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {course.avgTime}h
            </div>
            <p className="text-xs text-gray-500">
              Tempo médio de conclusão
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Taxa de Engajamento
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
                    <div className="text-2xl font-bold text-blue-600">
                      {formatPercentage(course.engagement || 0)}
                    </div>
            <p className="text-xs text-gray-500">
              Pontuação de engajamento dos alunos
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Learning Progress */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-[#1B262D]">Progresso de Aprendizagem</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Módulos Concluídos</span>
                  <span className="text-sm font-semibold">3 de 5</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-[#CE1C5A] h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Exercícios Realizados</span>
                  <span className="text-sm font-semibold">18 de 25</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: '72%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Quizzes Aprovados</span>
                  <span className="text-sm font-semibold">8 de 10</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '80%' }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Student Engagement Patterns */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-[#1B262D]">Padrões de Engajamento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-xs text-gray-600">Horário Preferido</span>
                <span className="text-sm font-semibold">19h-21h</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-xs text-gray-600">Dia Mais Ativo</span>
                <span className="text-sm font-semibold">Quarta</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-xs text-gray-600">Sessão Média</span>
                <span className="text-sm font-semibold">42 min</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-xs text-gray-600">Intervalo entre Acessos</span>
                <span className="text-sm font-semibold">2.3 dias</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content Performance */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-[#1B262D]">Performance do Conteúdo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                <span className="text-xs text-gray-600">Melhor Unidade</span>
                <span className="text-sm font-semibold text-green-600">React Hooks</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-red-50 rounded">
                <span className="text-xs text-gray-600">Maior Dificuldade</span>
                <span className="text-sm font-semibold text-red-600">Context API</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-amber-50 rounded">
                <span className="text-xs text-gray-600">Requer Revisão</span>
                <span className="text-sm font-semibold text-amber-600">State Management</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                <span className="text-xs text-gray-600">Mais Revisitado</span>
                <span className="text-sm font-semibold text-blue-600">Components</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Students and Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Students */}
        <Card>
          <CardHeader>
            <CardTitle className="text-[#1B262D]">Ranking de Alunos</CardTitle>
            <CardDescription>Alunos com melhor desempenho neste curso</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topStudents.map((student, index) => (
                <div key={student.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-gray-50 to-white rounded-lg hover:shadow-md transition-shadow">
                  <div className="flex items-center space-x-3">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full font-bold text-sm ${
                      index === 0 ? 'bg-gradient-to-br from-yellow-400 to-yellow-500 text-white' :
                      index === 1 ? 'bg-gradient-to-br from-gray-300 to-gray-400 text-white' :
                      index === 2 ? 'bg-gradient-to-br from-orange-400 to-orange-500 text-white' :
                      'bg-gray-100 text-gray-600'
                    }`}>
                      {index + 1}º
                    </div>
                    <div>
                      <p className="font-semibold text-[#1B262D]">{student.name}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-xs text-gray-500">
                          {formatPercentage(student.courses.find(c => c.courseId === course.id)?.progress || 0)} concluído
                        </span>
                        <span className="text-xs text-green-600 font-medium">
                          {student.engagement >= 80 ? '🔥 Em alta' : ''}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-[#CE1C5A]">{student.totalTime}h</p>
                    <p className="text-xs text-gray-500">Último acesso: {student.lastAccess.toLocaleDateString('pt-BR')}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Learning Insights */}
        <Card>
          <CardHeader>
            <CardTitle className="text-[#1B262D]">Insights de Aprendizagem</CardTitle>
            <CardDescription>Descobertas e recomendações baseadas em dados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="p-3 rounded-lg border border-gray-200 bg-green-50/30 hover:bg-green-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <TrendingUp className="h-4 w-4 text-green-600/70 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Momento de Aprendizagem Ideal</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      78% dos alunos têm melhor retenção quando estudam entre 19h-21h
                    </p>
                  </div>
                  <span className="text-xs text-green-700 font-medium">+23%</span>
                </div>
              </div>

              <div className="p-3 rounded-lg border border-gray-200 bg-amber-50/30 hover:bg-amber-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <Target className="h-4 w-4 text-amber-600/70 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Ponto de Atenção</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Módulo 3 tem 45% de abandono - considere revisar a complexidade
                    </p>
                  </div>
                  <span className="text-xs text-amber-700 font-medium">!</span>
                </div>
              </div>

              <div className="p-3 rounded-lg border border-gray-200 bg-blue-50/30 hover:bg-blue-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <Activity className="h-4 w-4 text-blue-600/70 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Padrão de Sucesso</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Alunos que fazem exercícios práticos têm 3x mais chance de conclusão
                    </p>
                  </div>
                  <span className="text-xs text-blue-700 font-medium">3x</span>
                </div>
              </div>

              <div className="p-3 rounded-lg border border-gray-200 bg-purple-50/30 hover:bg-purple-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <Star className="h-4 w-4 text-purple-600/70 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Conteúdo Valorizado</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Vídeos com exemplos práticos recebem 92% de avaliação positiva
                    </p>
                  </div>
                  <span className="text-xs text-purple-700 font-medium">92%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Course Health Dashboard */}
      <Card>
        <CardHeader>
          <CardTitle className="text-[#1B262D]">Saúde Geral do Curso</CardTitle>
          <CardDescription>Indicadores de qualidade e efetividade do curso</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
              <div className="text-2xl font-bold text-green-600">A+</div>
              <div className="text-xs text-gray-600 mt-1">Nota Geral</div>
              <div className="text-xs text-green-600 font-medium mt-1">Excelente</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">4.8</div>
              <div className="text-xs text-gray-600 mt-1">Avaliação</div>
              <div className="flex justify-center mt-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`h-3 w-3 ${i < 5 ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
                ))}
              </div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">92%</div>
              <div className="text-xs text-gray-600 mt-1">Recomendação</div>
              <div className="text-xs text-purple-600 font-medium mt-1">Altíssima</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg">
              <div className="text-2xl font-bold text-amber-600">3.2</div>
              <div className="text-xs text-gray-600 mt-1">Tentativas Média</div>
              <div className="text-xs text-amber-600 font-medium mt-1">Normal</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-lg">
              <div className="text-2xl font-bold text-red-600">18%</div>
              <div className="text-xs text-gray-600 mt-1">Taxa Desistência</div>
              <div className="text-xs text-red-600 font-medium mt-1">Atenção</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-teal-50 to-teal-100 rounded-lg">
              <div className="text-2xl font-bold text-teal-600">87%</div>
              <div className="text-xs text-gray-600 mt-1">Aplicabilidade</div>
              <div className="text-xs text-teal-600 font-medium mt-1">Prático</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Learning Paths and Prerequisites */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Prerequisites and Next Steps */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-[#1B262D]">Jornada de Aprendizagem</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-600 mb-2">Pré-requisitos Recomendados</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm text-gray-700">JavaScript Básico</span>
                  <Badge variant="outline" className="text-xs">Essencial</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm text-gray-700">HTML & CSS</span>
                  <Badge variant="outline" className="text-xs">Importante</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-sm text-gray-700">Lógica de Programação</span>
                  <Badge variant="outline" className="text-xs">Básico</Badge>
                </div>
              </div>
            </div>
            <div className="pt-3 border-t">
              <h4 className="text-sm font-medium text-gray-600 mb-2">Próximos Passos Sugeridos</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-[#CE1C5A]/10 rounded">
                  <span className="text-sm text-gray-700 font-medium">React Advanced Patterns</span>
                  <ArrowRight className="h-4 w-4 text-[#CE1C5A]" />
                </div>
                <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                  <span className="text-sm text-gray-700">Next.js Framework</span>
                  <ArrowRight className="h-4 w-4 text-blue-600" />
                </div>
                <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                  <span className="text-sm text-gray-700">TypeScript com React</span>
                  <ArrowRight className="h-4 w-4 text-green-600" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Time Investment Analysis */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-[#1B262D]">Análise de Investimento de Tempo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Vídeos (40%)</span>
                  <span className="text-sm font-semibold">8h</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: '40%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Exercícios (30%)</span>
                  <span className="text-sm font-semibold">6h</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Leitura (20%)</span>
                  <span className="text-sm font-semibold">4h</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-purple-500 h-2 rounded-full" style={{ width: '20%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-600">Projetos (10%)</span>
                  <span className="text-sm font-semibold">2h</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-amber-500 h-2 rounded-full" style={{ width: '10%' }}></div>
                </div>
              </div>
            </div>
            <div className="pt-3 border-t">
              <div className="grid grid-cols-2 gap-3">
                <div className="text-center p-2 bg-gray-50 rounded">
                  <div className="text-lg font-bold text-[#1B262D]">20h</div>
                  <div className="text-xs text-gray-500">Tempo Total</div>
                </div>
                <div className="text-center p-2 bg-gray-50 rounded">
                  <div className="text-lg font-bold text-[#1B262D]">2-3 sem</div>
                  <div className="text-xs text-gray-500">Duração Sugerida</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Comparison with Similar Courses */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base text-[#1B262D]">Comparação com Cursos Similares</CardTitle>
          <CardDescription>Como este curso se compara com outros da mesma categoria</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-2 px-3 text-xs font-medium text-gray-600 uppercase">Métrica</th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-gray-600 uppercase">Este Curso</th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-gray-600 uppercase">Média da Categoria</th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-gray-600 uppercase">Top 10%</th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-gray-600 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr className="hover:bg-gray-50">
                  <td className="py-2 px-3 text-sm text-gray-700">Taxa de Conclusão</td>
                  <td className="py-2 px-3 text-center font-semibold text-green-600">78%</td>
                  <td className="py-2 px-3 text-center text-gray-600">65%</td>
                  <td className="py-2 px-3 text-center text-gray-600">85%</td>
                  <td className="py-2 px-3 text-center">
                    <Badge variant="outline" className="text-xs bg-green-50 text-green-700">Acima da Média</Badge>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="py-2 px-3 text-sm text-gray-700">Engajamento</td>
                  <td className="py-2 px-3 text-center font-semibold text-green-600">85%</td>
                  <td className="py-2 px-3 text-center text-gray-600">72%</td>
                  <td className="py-2 px-3 text-center text-gray-600">90%</td>
                  <td className="py-2 px-3 text-center">
                    <Badge variant="outline" className="text-xs bg-green-50 text-green-700">Excelente</Badge>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="py-2 px-3 text-sm text-gray-700">Tempo Médio</td>
                  <td className="py-2 px-3 text-center font-semibold text-blue-600">20h</td>
                  <td className="py-2 px-3 text-center text-gray-600">25h</td>
                  <td className="py-2 px-3 text-center text-gray-600">18h</td>
                  <td className="py-2 px-3 text-center">
                    <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700">Otimizado</Badge>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="py-2 px-3 text-sm text-gray-700">Satisfação</td>
                  <td className="py-2 px-3 text-center font-semibold text-purple-600">4.8</td>
                  <td className="py-2 px-3 text-center text-gray-600">4.2</td>
                  <td className="py-2 px-3 text-center text-gray-600">4.9</td>
                  <td className="py-2 px-3 text-center">
                    <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700">Top Tier</Badge>
                  </td>
                </tr>
                <tr className="hover:bg-gray-50">
                  <td className="py-2 px-3 text-sm text-gray-700">Taxa de Retenção</td>
                  <td className="py-2 px-3 text-center font-semibold text-amber-600">82%</td>
                  <td className="py-2 px-3 text-center text-gray-600">70%</td>
                  <td className="py-2 px-3 text-center text-gray-600">88%</td>
                  <td className="py-2 px-3 text-center">
                    <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700">Bom</Badge>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}