'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { mockCourses } from '@/lib/data'
import { formatPercentage } from '@/lib/utils'
import { Search, Filter, Star, Users, Clock, TrendingUp, Eye, MoreHorizontal, CheckCircle, BookOpen, Layers } from 'lucide-react'

export default function CoursesPage() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedStatus, setSelectedStatus] = useState('all')
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  const statuses = ['all', 'active', 'inactive', 'draft']

  const filteredCourses = mockCourses.filter(course => {
    const matchesSearch = course.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = selectedStatus === 'all' || course.status === selectedStatus
    
    return matchesSearch && matchesStatus
  })

  // Paginação
  const totalPages = Math.ceil(filteredCourses.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedCourses = filteredCourses.slice(startIndex, endIndex)

  // Reset para página 1 quando filtros mudam
  const handleSearchChange = (value: string) => {
    setSearchTerm(value)
    setCurrentPage(1)
  }

  const handleStatusChange = (value: string) => {
    setSelectedStatus(value)
    setCurrentPage(1)
  }

  // Sugestões para autocomplete
  const suggestions = mockCourses
    .filter(course => course.name.toLowerCase().includes(searchTerm.toLowerCase()) && searchTerm.length > 0)
    .slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Cursos</h1>
        <p className="text-gray-600 mt-1">
          Gerencie e analise o desempenho dos cursos
        </p>
      </div>

      {/* Modern Search */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
        <div className="flex-1 relative">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Pesquisar cursos..."
              value={searchTerm}
              onChange={(e) => {
                handleSearchChange(e.target.value)
                setShowSuggestions(e.target.value.length > 0)
              }}
              onFocus={() => setShowSuggestions(searchTerm.length > 0)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500"
            />
          </div>
          
          {/* Autocomplete Suggestions */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto">
              {suggestions.map((course) => (
                <div
                  key={course.id}
                  onClick={() => {
                    setSearchTerm(course.name)
                    setShowSuggestions(false)
                  }}
                  className="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0 transition-colors"
                >
                  <div className="font-medium text-gray-900">{course.name}</div>
                  <div className="text-sm text-gray-500">
                    {course.students} alunos • {formatPercentage(course.completionRate)} conclusão • {formatPercentage(course.engagement)} engajamento
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="flex gap-3">
          <select
            value={selectedStatus}
            onChange={(e) => handleStatusChange(e.target.value)}
            className="px-5 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#CE1C5A] focus:border-transparent transition-all duration-200 text-gray-900 font-medium shadow-sm hover:border-gray-300 cursor-pointer appearance-none bg-no-repeat bg-right pr-10"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
              backgroundPosition: 'right 0.5rem center',
              backgroundSize: '1.5em 1.5em'
            }}
          >
            {statuses.map(status => (
              <option key={status} value={status}>
                {status === 'all' ? 'Todos os Status' : 
                 status === 'active' ? 'Ativo' :
                 status === 'inactive' ? 'Inativo' : 'Rascunho'}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Courses Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-4 px-6 font-medium text-gray-600 text-xs uppercase">Curso</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-600 text-xs uppercase">Módulos</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-600 text-xs uppercase">Engajamento</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-600 text-xs uppercase">Alunos</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-600 text-xs uppercase">Tempo Médio</th>
                  <th className="text-left py-4 px-6 font-medium text-gray-600 text-xs uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {paginatedCourses.map((course, index) => (
                  <tr key={course.id} className={`hover:bg-gray-100 transition-colors duration-150 cursor-pointer ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`} onClick={() => router.push(`/courses/${course.id}`)}>
                    <td className="py-5 px-6">
                      <div>
                        <div className="font-semibold text-gray-900 text-base">{course.name}</div>
                        <div className="text-sm text-gray-500 mt-1">
                          {course.avgTime}h médio
                        </div>
                      </div>
                    </td>
                    <td className="py-5 px-6">
                      <div className="flex items-center text-gray-600">
                        <Layers className="h-5 w-5 mr-2 text-gray-400" />
                        <span className="font-medium text-base">{course.modules?.length || 0}</span>
                      </div>
                    </td>
                    <td className="py-5 px-6">
                      <div className="flex items-center">
                        {course.engagement >= 70 ? (
                          <TrendingUp className="h-5 w-5 mr-2 text-green-500" />
                        ) : course.engagement >= 50 ? (
                          <TrendingUp className="h-5 w-5 mr-2 text-yellow-500" />
                        ) : (
                          <TrendingUp className="h-5 w-5 mr-2 text-red-500 rotate-180" />
                        )}
                        <span className={`font-semibold text-base ${
                          course.engagement >= 70 ? 'text-green-600' :
                          course.engagement >= 50 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {formatPercentage(course.engagement)}
                        </span>
                      </div>
                    </td>
                    <td className="py-5 px-6">
                      <div className="flex items-center text-gray-600">
                        <Users className="h-5 w-5 mr-2 text-gray-400" />
                        <span className="font-medium text-base">{course.students}</span>
                      </div>
                    </td>
                    <td className="py-5 px-6">
                      <div className="flex items-center text-gray-600">
                        <Clock className="h-5 w-5 mr-2 text-gray-400" />
                        <span className="font-medium text-base">{course.avgTime}h</span>
                      </div>
                    </td>
                    <td className="py-5 px-6">
                      <Badge 
                        variant={course.status === 'active' ? 'default' : 'secondary'}
                        className="px-3 py-1 text-xs font-medium"
                      >
                        {course.status === 'active' ? 'Ativo' : 
                         course.status === 'inactive' ? 'Inativo' : 'Rascunho'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>

        {/* Paginação */}
        {totalPages > 1 && (
          <div className="px-4 py-4 border-t border-gray-200">
            <div className="flex flex-col items-center gap-3">
              <div className="text-sm text-gray-600">
                Mostrando {startIndex + 1} a {Math.min(endIndex, filteredCourses.length)} de {filteredCourses.length} cursos
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="h-8 px-3"
                >
                  Anterior
                </Button>
                <div className="flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                      className={`h-8 w-8 p-0 ${currentPage === page ? 'bg-[#CE1C5A] hover:bg-[#CE1C5A]/90' : ''}`}
                    >
                      {page}
                    </Button>
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  className="h-8 px-3"
                >
                  Próxima
                </Button>
              </div>
            </div>
          </div>
        )}
      </Card>

      {filteredCourses.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="text-gray-500">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium mb-2">Nenhum curso encontrado</h3>
              <p>Tente ajustar os filtros ou criar um novo curso.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
