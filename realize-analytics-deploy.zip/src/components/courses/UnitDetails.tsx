'use client'

import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { mockCourses } from '@/lib/data'
import { 
  ArrowLeft, 
  Clock,
  BookOpen,
  FileText,
  CheckCircle,
  TrendingUp,
  AlertCircle,
  Activity
} from 'lucide-react'

interface UnitDetailsProps {
  courseId: string
  moduleId: string
  unitId: string
}

const unitTypeLabels = {
  video: 'Vídeo',
  text: 'Leitura',
  quiz: 'Quiz',
  assignment: 'Exercício',
  live: 'Ao Vivo',
}

export default function UnitDetails({ courseId, moduleId, unitId }: UnitDetailsProps) {
  const router = useRouter()
  const course = mockCourses.find(c => c.id === courseId)
  const module = course?.modules.find(m => m.id === moduleId)
  const unit = module?.units.find(u => u.id === unitId)

  if (!course || !module || !unit) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-12 text-center">
            <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium mb-2">Unidade não encontrada</h3>
            <p className="text-gray-500">A unidade solicitada não existe.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => router.push(`/courses/${courseId}`)}
            >
              Voltar ao Curso
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return hours > 0 ? `${hours}h ${mins}min` : `${mins}min`
  }

  const progress = unit.isCompleted ? 100 : (unit.progress || 0)

  // Get unit index in module
  const unitIndex = module.units.findIndex(u => u.id === unitId)
  const prevUnit = unitIndex > 0 ? module.units[unitIndex - 1] : null
  const nextUnit = unitIndex < module.units.length - 1 ? module.units[unitIndex + 1] : null

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => router.push(`/courses/${courseId}`)}
          className="hover:bg-gray-100"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar ao Curso
        </Button>
        
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-sm text-gray-500">Módulo: {module.name}</span>
            <span className="text-sm text-gray-400">•</span>
            <span className="text-sm text-[#CE1C5A] font-medium">Unidade {unitIndex + 1} de {module.units.length}</span>
          </div>
          <h1 className="text-3xl font-bold text-[#1B262D] mb-3">{unit.name}</h1>
          <p className="text-lg text-gray-600 mb-4">{unit.description}</p>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1 text-sm text-gray-500">
              <Clock className="h-4 w-4" />
              <span>Duração: {formatDuration(unit.duration)}</span>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              className="text-[#CE1C5A] border-[#CE1C5A] hover:bg-[#CE1C5A]/10"
            >
              Visualizar Unidade
            </Button>
          </div>
        </div>
      </div>

      {/* Performance Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Performance Card */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base text-[#1B262D]">Performance da Unidade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                <div className="flex items-center justify-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="text-2xl font-bold text-green-600">85%</span>
                </div>
                <p className="text-xs text-gray-600 mt-1">Engajamento</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">78%</div>
                <p className="text-xs text-gray-600 mt-1">Conclusão</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">92%</div>
                <p className="text-xs text-gray-600 mt-1">Satisfação</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg">
                <div className="text-2xl font-bold text-amber-600">4.8</div>
                <p className="text-xs text-gray-600 mt-1">Avaliação</p>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-gray-500">Tempo Médio</span>
                    <span className="text-sm font-semibold">35 min</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div className="bg-[#CE1C5A] h-1.5 rounded-full" style={{ width: '70%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-gray-500">Tentativas</span>
                    <span className="text-sm font-semibold">1.3</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: '26%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-gray-500">Retenção</span>
                    <span className="text-sm font-semibold">94%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5">
                    <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '94%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Student Activity Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-[#1B262D]">Atividade dos Alunos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm text-gray-700">Alunos Ativos</span>
              <span className="text-lg font-bold text-[#1B262D]">124</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm text-gray-700">Visualizações Hoje</span>
              <span className="text-lg font-bold text-[#1B262D]">47</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm text-gray-700">Média de Revisitas</span>
              <span className="text-lg font-bold text-[#1B262D]">3.2</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm text-gray-700">Dúvidas no Fórum</span>
              <span className="text-lg font-bold text-[#1B262D]">18</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Resources Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recursos Interativos */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-[#1B262D]">Recursos Interativos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5 max-h-[400px] overflow-y-auto">
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Abas</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">12</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Hotspots</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">8</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Tooltips</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">15</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Pop-ups</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">6</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Accordions</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">4</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Carrosséis</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">7</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Timeline</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">3</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Flip Cards</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">9</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Drag & Drop</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">5</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Zoom Areas</span>
              <span className="text-sm font-semibold text-[#CE1C5A]">11</span>
            </div>
            <div className="pt-2 mt-2 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Total de Interações</span>
                <span className="text-sm font-bold text-[#1B262D]">80</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recursos de Mídia */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-[#1B262D]">Recursos de Mídia</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Vídeos</span>
              <span className="text-sm font-semibold text-blue-600">3</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Áudios</span>
              <span className="text-sm font-semibold text-blue-600">2</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Imagens</span>
              <span className="text-sm font-semibold text-blue-600">18</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">Infográficos</span>
              <span className="text-sm font-semibold text-blue-600">5</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <span className="text-sm text-gray-700">PDFs</span>
              <span className="text-sm font-semibold text-blue-600">7</span>
            </div>
            <div className="pt-2 mt-2 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Total de Mídias</span>
                <span className="text-sm font-bold text-[#1B262D]">35</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recursos Mais Usados */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-[#1B262D]">Mais Acessados pelos Alunos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
                <div className="p-2 bg-[#CE1C5A]/10 rounded border-l-4 border-l-[#CE1C5A]">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700 font-medium">Vídeo Introdutório</span>
                    <span className="text-xs text-[#CE1C5A] font-semibold">92%</span>
                  </div>
                </div>
                <div className="p-2 bg-blue-50 rounded border-l-4 border-l-blue-500">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700 font-medium">Exercício Prático</span>
                    <span className="text-xs text-blue-600 font-semibold">87%</span>
                  </div>
                </div>
                <div className="p-2 bg-green-50 rounded border-l-4 border-l-green-500">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700 font-medium">Infográfico Resumo</span>
                    <span className="text-xs text-green-600 font-semibold">85%</span>
                  </div>
                </div>
                <div className="p-2 bg-gray-50 rounded">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">PDF Material</span>
                    <span className="text-xs text-gray-600 font-semibold">72%</span>
                  </div>
                </div>
                <div className="p-2 bg-gray-50 rounded">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Links Externos</span>
                    <span className="text-xs text-gray-600 font-semibold">68%</span>
                  </div>
                </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Text Statistics */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-[#1B262D]">Análise do Conteúdo Textual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-3 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                <div className="text-xl font-bold text-[#1B262D]">12.450</div>
                <div className="text-xs text-gray-500">Caracteres</div>
              </div>
              <div className="text-center p-3 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                <div className="text-xl font-bold text-[#1B262D]">2.180</div>
                <div className="text-xs text-gray-500">Palavras</div>
              </div>
              <div className="text-center p-3 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                <div className="text-xl font-bold text-[#1B262D]">48</div>
                <div className="text-xs text-gray-500">Parágrafos</div>
              </div>
              <div className="text-center p-3 bg-gradient-to-br from-[#CE1C5A]/10 to-[#CE1C5A]/20 rounded-lg">
                <div className="text-xl font-bold text-[#CE1C5A]">8 min</div>
                <div className="text-xs text-gray-500">Tempo Leitura</div>
              </div>
              <div className="text-center p-3 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                <div className="text-xl font-bold text-blue-600">324</div>
                <div className="text-xs text-gray-500">Linhas</div>
              </div>
              <div className="text-center p-3 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                <div className="text-xl font-bold text-green-600">8</div>
                <div className="text-xs text-gray-500">Páginas</div>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Complexidade do Texto</span>
                  <span className="font-semibold text-amber-600">Intermediário</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Índice de Legibilidade</span>
                  <span className="font-semibold text-green-600">8.5/10</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Densidade de Palavras-chave</span>
                  <span className="font-semibold">3.2%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Learning Insights */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-[#1B262D]">Insights de Aprendizagem</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="p-3 rounded-lg border border-gray-200 bg-green-50/30 hover:bg-green-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Ponto Forte</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Alta retenção nos exercícios práticos
                    </p>
                  </div>
                  <span className="text-xs text-green-700 font-medium">+15%</span>
                </div>
              </div>

              <div className="p-3 rounded-lg border border-gray-200 bg-amber-50/30 hover:bg-amber-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-4 w-4 text-amber-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Atenção</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Baixo engajamento em vídeos longos
                    </p>
                  </div>
                  <span className="text-xs text-amber-700 font-medium">-8%</span>
                </div>
              </div>

              <div className="p-3 rounded-lg border border-gray-200 bg-blue-50/30 hover:bg-blue-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <TrendingUp className="h-4 w-4 text-blue-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Oportunidade</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Adicionar mais conteúdo interativo
                    </p>
                  </div>
                  <span className="text-xs text-blue-700 font-medium">↑</span>
                </div>
              </div>

              <div className="p-3 rounded-lg border border-gray-200 bg-purple-50/30 hover:bg-purple-50/50 transition-all">
                <div className="flex items-start gap-3">
                  <Activity className="h-4 w-4 text-purple-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-medium text-[#1B262D] text-sm">Tendência</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Aumento de 23% nas revisitas semanais
                    </p>
                  </div>
                  <span className="text-xs text-purple-700 font-medium">+23%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* User Behavior Analytics */}
      <div className="space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base text-[#1B262D]">Análise Comportamental dos Alunos</CardTitle>
            <CardDescription>Métricas detalhadas de interação e comportamento</CardDescription>
          </CardHeader>
        </Card>

        {/* Key Metrics Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm text-[#1B262D]">Visão Geral</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-red-50 rounded-lg border border-red-100">
                <div className="text-2xl font-bold text-red-600">32%</div>
                <div className="text-xs text-red-600 mt-1 font-medium">Taxa de Rejeição</div>
                <div className="text-xs text-gray-500 mt-1">Acima da média</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg border border-green-100">
                <div className="text-2xl font-bold text-green-600">76%</div>
                <div className="text-xs text-green-600 mt-1 font-medium">Taxa de Retorno</div>
                <div className="text-xs text-gray-500 mt-1">Excelente</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-100">
                <div className="text-2xl font-bold text-blue-600">4:23</div>
                <div className="text-xs text-blue-600 mt-1 font-medium">Tempo Médio</div>
                <div className="text-xs text-gray-500 mt-1">Por sessão</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg border border-purple-100">
                <div className="text-2xl font-bold text-purple-600">68%</div>
                <div className="text-xs text-purple-600 mt-1 font-medium">Mobile</div>
                <div className="text-xs text-gray-500 mt-1">Usuários móveis</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Engagement Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Interaction Points */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm text-[#1B262D]">Pontos de Interação</CardTitle>
              <CardDescription>Taxa de cliques por elemento</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-sm text-gray-700">Vídeo Principal</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[89%] h-full bg-blue-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">89%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-700">Exercícios</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[67%] h-full bg-green-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">67%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                    <span className="text-sm text-gray-700">Downloads</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[45%] h-full bg-amber-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">45%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                    <span className="text-sm text-gray-700">Links Externos</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[23%] h-full bg-gray-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">23%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Scroll Depth Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm text-[#1B262D]">Profundidade de Leitura</CardTitle>
              <CardDescription>Percentual de alunos por seção</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">25% da página</span>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[95%] h-full bg-green-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">95%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">50% da página</span>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[78%] h-full bg-blue-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">78%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">75% da página</span>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[56%] h-full bg-amber-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">56%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">100% da página</span>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-3 bg-gray-200 rounded-full overflow-hidden">
                      <div className="w-[34%] h-full bg-red-500"></div>
                    </div>
                    <span className="text-sm font-semibold text-gray-700 w-8 text-right">34%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Behavior Indicators */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Distraction Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm text-[#1B262D]">Indicadores de Distração</CardTitle>
              <CardDescription>Comportamentos que indicam falta de foco</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Mudanças de Aba</div>
                    <div className="text-xs text-gray-500">Por sessão</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-[#1B262D]">3.2</div>
                    <div className="text-xs text-amber-600">⚠️ Alto</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Pausas no Vídeo</div>
                    <div className="text-xs text-gray-500">Por vídeo</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-[#1B262D]">5.8</div>
                    <div className="text-xs text-gray-600">Normal</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Scroll Rápido</div>
                    <div className="text-xs text-gray-500">Percentual</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-amber-600">12%</div>
                    <div className="text-xs text-amber-600">⚠️ Atenção</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Cliques Vazios</div>
                    <div className="text-xs text-gray-500">Percentual</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-amber-600">8%</div>
                    <div className="text-xs text-amber-600">⚠️ Atenção</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Session Analytics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm text-[#1B262D]">Análise de Sessão</CardTitle>
              <CardDescription>Padrões de uso e acesso</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Sessões/Aluno</div>
                    <div className="text-xs text-gray-500">Média geral</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-[#1B262D]">2.4</div>
                    <div className="text-xs text-green-600">✓ Bom</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Dispositivo Mobile</div>
                    <div className="text-xs text-gray-500">Percentual</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-[#1B262D]">38%</div>
                    <div className="text-xs text-blue-600">📱 Mobile</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Horário de Pico</div>
                    <div className="text-xs text-gray-500">Maior atividade</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-[#1B262D]">20h-22h</div>
                    <div className="text-xs text-purple-600">🌙 Noite</div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="text-sm font-medium text-gray-900">Dia Mais Ativo</div>
                    <div className="text-xs text-gray-500">Semana</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-[#1B262D]">Terça</div>
                    <div className="text-xs text-green-600">📅 Terça</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Behavior Patterns */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm text-[#1B262D]">Padrões Detectados</CardTitle>
            <CardDescription>Análise comportamental consolidada</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-red-50 rounded-lg border border-red-200">
                <div className="text-2xl font-bold text-red-600">23%</div>
                <div className="text-sm font-medium text-red-800 mt-1">Alto Abandono</div>
                <div className="text-xs text-gray-600 mt-1">Saem antes de 2min</div>
              </div>
              <div className="text-center p-4 bg-amber-50 rounded-lg border border-amber-200">
                <div className="text-2xl font-bold text-amber-600">15%</div>
                <div className="text-sm font-medium text-amber-800 mt-1">Frustração</div>
                <div className="text-xs text-gray-600 mt-1">Cliques em áreas inativas</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="text-2xl font-bold text-green-600">68%</div>
                <div className="text-sm font-medium text-green-800 mt-1">Engajamento</div>
                <div className="text-xs text-gray-600 mt-1">Comportamento positivo</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-2xl font-bold text-blue-600">82%</div>
                <div className="text-sm font-medium text-blue-800 mt-1">Retenção</div>
                <div className="text-xs text-gray-600 mt-1">Conteúdo absorvido</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        {prevUnit ? (
          <Button
            variant="outline"
            onClick={() => router.push(`/courses/${courseId}/modules/${moduleId}/units/${prevUnit.id}`)}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Anterior: {prevUnit.name}
          </Button>
        ) : (
          <div></div>
        )}

        {nextUnit ? (
          <Button
            onClick={() => router.push(`/courses/${courseId}/modules/${moduleId}/units/${nextUnit.id}`)}
            className="bg-[#CE1C5A] hover:bg-[#CE1C5A]/90"
          >
            Próxima: {nextUnit.name}
            <ArrowLeft className="h-4 w-4 ml-2 rotate-180" />
          </Button>
        ) : (
          <Button
            onClick={() => router.push(`/courses/${courseId}`)}
            className="bg-green-600 hover:bg-green-700"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Concluir Módulo
          </Button>
        )}
      </div>
    </div>
  )
}
