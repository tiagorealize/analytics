'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Course, Module } from '@/lib/types'
import { 
  Clock, 
  ChevronDown,
  Layers
} from 'lucide-react'

interface CourseStructureProps {
  course: Course
}

export function CourseStructure({ course }: CourseStructureProps) {
  const router = useRouter()
  const [expandedModules, setExpandedModules] = useState<string[]>([])

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return hours > 0 ? `${hours}h ${mins}min` : `${mins}min`
  }

  const getModuleProgress = (module: Module) => {
    const totalUnits = module.units.length
    const completedUnits = module.units.filter(unit => unit.isCompleted).length
    return totalUnits > 0 ? (completedUnits / totalUnits) * 100 : 0
  }

  const toggleModule = (moduleId: string) => {
    setExpandedModules(prev => 
      prev.includes(moduleId) 
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    )
  }

  const handleUnitClick = (moduleId: string, unitId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    router.push(`/courses/${course.id}/modules/${moduleId}/units/${unitId}`)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-[#1B262D]">Estrutura do Curso</CardTitle>
        <CardDescription>
          {course.modules?.length || 0} módulos • {course.modules?.reduce((acc, module) => acc + module.units.length, 0) || 0} unidades • {formatDuration(course.totalDuration || 0)}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {(course.modules || []).map((module, moduleIndex) => {
          const moduleProgress = getModuleProgress(module)
          const completedUnits = module.units.filter(unit => unit.isCompleted).length
          const totalUnits = module.units.length
          const isExpanded = expandedModules.includes(module.id)

          return (
            <div key={module.id} className="border border-gray-200 rounded-lg overflow-hidden border-l-4 border-l-[#CE1C5A]">
              {/* Module Header */}
              <div 
                className="p-5 cursor-pointer hover:bg-gray-50 transition-all duration-200"
                onClick={() => toggleModule(module.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 text-base mb-1">{module.name}</h3>
                    <p className="text-sm text-gray-500">{module.description}</p>
                  </div>
                  <div className="flex items-center gap-6 ml-4 flex-shrink-0">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{formatDuration(module.duration)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Layers className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{totalUnits}</span>
                    </div>
                    <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#CE1C5A]/10 flex-shrink-0">
                      <ChevronDown className={`h-4 w-4 text-[#CE1C5A] transition-transform duration-200 ${isExpanded ? '' : '-rotate-90'}`} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Units List (Accordion Content) */}
              {isExpanded && (
                <div className="border-t border-gray-200 bg-gray-50/50 p-4">
                  <div className="space-y-2">
                    {module.units.map((unit, unitIndex) => {
                      return (
                        <div 
                          key={unit.id}
                          className="bg-white border border-gray-200 rounded-lg p-4 cursor-pointer hover:shadow-md hover:border-[#CE1C5A]/30 transition-all duration-200 border-l-4 border-l-blue-500"
                          onClick={(e) => handleUnitClick(module.id, unit.id, e)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3 flex-1">
                              <div className="flex items-center justify-center w-6 h-6 rounded-full bg-gray-100 text-gray-600 font-medium text-xs">
                                {unitIndex + 1}
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900 text-sm">{unit.name}</h4>
                                <p className="text-xs text-gray-500 mt-0.5">{unit.description}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-1 text-xs text-gray-600">
                              <Clock className="h-3 w-3" />
                              <span>{formatDuration(unit.duration)}</span>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}

