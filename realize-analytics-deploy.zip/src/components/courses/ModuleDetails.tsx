'use client'

import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { mockCourses } from '@/lib/data'
import { 
  ArrowLeft, 
  Clock,
  CheckCircle,
  Circle,
  Play,
  FileText,
  HelpCircle,
  Edit,
  Video,
  BookOpen,
  Users,
  TrendingUp
} from 'lucide-react'

interface ModuleDetailsProps {
  courseId: string
  moduleId: string
}

const unitTypeIcons = {
  video: Video,
  text: FileText,
  quiz: HelpCircle,
  assignment: Edit,
  live: Play,
}

const unitTypeColors = {
  video: 'from-blue-500 to-blue-600',
  text: 'from-gray-500 to-gray-600',
  quiz: 'from-purple-500 to-purple-600',
  assignment: 'from-green-500 to-green-600',
  live: 'from-red-500 to-red-600',
}

const unitTypeLabels = {
  video: 'Vídeo',
  text: 'Leitura',
  quiz: 'Quiz',
  assignment: 'Exercício',
  live: 'Ao Vivo',
}

export default function ModuleDetails({ courseId, moduleId }: ModuleDetailsProps) {
  const router = useRouter()
  const course = mockCourses.find(c => c.id === courseId)
  const module = course?.modules.find(m => m.id === moduleId)

  if (!course || !module) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-12 text-center">
            <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium mb-2">Módulo não encontrado</h3>
            <p className="text-gray-500">O módulo solicitado não existe.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => router.push(`/courses/${courseId}`)}
            >
              Voltar ao Curso
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return hours > 0 ? `${hours}h ${mins}min` : `${mins}min`
  }

  const completedUnits = module.units.filter(unit => unit.isCompleted).length
  const totalUnits = module.units.length
  const moduleProgress = totalUnits > 0 ? (completedUnits / totalUnits) * 100 : 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => router.push(`/courses/${courseId}`)}
          className="hover:bg-gray-100"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar ao Curso
        </Button>
        
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-[#1B262D] mb-2">{module.name}</h1>
            <p className="text-lg text-gray-600 mb-4">{module.description}</p>
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <div className="flex items-center space-x-1">
                <BookOpen className="h-4 w-4" />
                <span>Curso: {course.name}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span>{formatDuration(module.duration)}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Users className="h-4 w-4" />
                <span>{totalUnits} unidades</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Module Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Progresso
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#CE1C5A]">
              {Math.round(moduleProgress)}%
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {completedUnits} de {totalUnits} unidades
            </p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
              <div 
                className="bg-gradient-to-r from-[#CE1C5A] to-[#CE1C5A]/80 h-2 rounded-full transition-all duration-300" 
                style={{ width: `${moduleProgress}%` }}
              ></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#1B262D]">
              Duração Total
            </CardTitle>
            <Clock className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatDuration(module.duration)}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Tempo estimado de conclusão
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Units List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-[#1B262D]">Unidades do Módulo</CardTitle>
          <CardDescription>
            {totalUnits} unidades • {formatDuration(module.duration)}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {module.units.map((unit, index) => {
            const IconComponent = unitTypeIcons[unit.type]
            const colorGradient = unitTypeColors[unit.type]
            const isCompleted = unit.isCompleted

            return (
              <div 
                key={unit.id} 
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all duration-200 cursor-pointer hover:bg-gray-50"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 flex-1">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 text-gray-600 font-semibold text-sm">
                      {index + 1}
                    </div>
                    <div className={`flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br ${colorGradient} shadow-lg`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-semibold text-gray-900 text-base">{unit.name}</h3>
                        <Badge variant="outline" className="text-xs">
                          {unitTypeLabels[unit.type]}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500">{unit.description}</p>
                      <div className="flex items-center space-x-1 text-sm text-gray-600 mt-2">
                        <Clock className="h-4 w-4" />
                        <span>{formatDuration(unit.duration)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {(unit.progress && unit.progress > 0) || isCompleted ? (
                      <>
                        <div className="w-24 bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-[#CE1C5A] h-2.5 rounded-full" 
                            style={{ width: `${isCompleted ? 100 : unit.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-semibold text-gray-700 w-12">
                          {isCompleted ? 100 : unit.progress}%
                        </span>
                      </>
                    ) : (
                      <>
                        <div className="w-24 bg-gray-200 rounded-full h-2.5">
                          <div className="bg-[#CE1C5A] h-2.5 rounded-full" style={{ width: '0%' }}></div>
                        </div>
                        <span className="text-sm font-semibold text-gray-700 w-12">0%</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </CardContent>
      </Card>
    </div>
  )
}

