import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ConditionalLayout } from '@/components/layout/ConditionalLayout'
import { GoogleAnalytics, GoogleTagManager, FacebookPixel } from '@/components/analytics/Analytics'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  metadataBase: new URL('https://realize-analytics.com'),
  title: 'Realize Analytics - Dashboard Educacional Inteligente',
  description: 'Realize Analytics é a plataforma de analytics educacional mais avançada para gestão de cursos, acompanhamento de alunos e insights de aprendizado. Transforme dados em decisões inteligentes.',
  keywords: 'analytics educacional, dashboard educacional, gestão de cursos, acompanhamento de alunos, insights de aprendizado, educação digital, LMS analytics',
  authors: [{ name: 'Realize Analytics' }],
  creator: 'Realize Analytics',
  publisher: 'Realize Analytics',
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'pt_BR',
    url: 'https://realize-analytics.com',
    siteName: 'Realize Analytics',
    title: 'Realize Analytics - Dashboard Educacional Inteligente',
    description: 'Plataforma de analytics educacional para gestão de cursos e acompanhamento de alunos',
    images: [
      {
        url: '/logo.svg',
        width: 1200,
        height: 630,
        alt: 'Realize Analytics - Dashboard Educacional',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Realize Analytics - Dashboard Educacional Inteligente',
    description: 'Plataforma de analytics educacional para gestão de cursos e acompanhamento de alunos',
    images: ['/logo.svg'],
    creator: '@realizeanalytics',
  },
  manifest: '/manifest.json',
}

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#CE1C5A',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <head>
        <GoogleAnalytics />
        <GoogleTagManager />
        <FacebookPixel />
      </head>
      <body className={inter.className}>
        <ConditionalLayout>
          {children}
        </ConditionalLayout>
      </body>
    </html>
  )
}
