import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { mockCourses } from '@/lib/data'

export default function UnitsTestPage() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold text-[#1B262D]">Unidades Disponíveis</h1>
      
      {mockCourses.map(course => (
        <Card key={course.id}>
          <CardHeader>
            <CardTitle className="text-[#1B262D]">{course.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {course.modules?.map(module => (
                <div key={module.id} className="border-l-4 border-[#CE1C5A] pl-4">
                  <h3 className="font-semibold text-[#1B262D] mb-2">{module.name}</h3>
                  <div className="space-y-2">
                    {module.units?.map(unit => (
                      <div key={unit.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div>
                          <span className="font-medium text-gray-900">{unit.name}</span>
                          <span className="text-sm text-gray-500 ml-2">({unit.type})</span>
                        </div>
                        <Link 
                          href={`/courses/${course.id}/modules/${module.id}/units/${unit.id}`}
                          className="text-[#CE1C5A] hover:underline text-sm"
                        >
                          Ver Unidade
                        </Link>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
