export default function TestPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Página de Teste</h1>
      <p className="text-gray-600">Se você está vendo esta página, a navegação está funcionando!</p>
      <div className="mt-4 space-x-4">
        <a href="/" className="text-blue-600 hover:underline">Voltar ao Dashboard</a>
        <a href="/courses" className="text-blue-600 hover:underline">Ir para Cursos</a>
        <a href="/students" className="text-blue-600 hover:underline">Ir para Alunos</a>
      </div>
    </div>
  )
}
