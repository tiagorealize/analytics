import StudentDetails from '@/components/students/StudentDetails'

export default async function StudentPage({ 
  params 
}: { 
  params: Promise<{ id: string }> 
}) {
  const resolvedParams = await params
  
  return <StudentDetails studentId={resolvedParams.id} />
}
