import CourseAnalytics from '@/components/courses/CourseAnalytics'

interface CoursePageProps {
  params: Promise<{
    id: string
  }>
}

export default async function CoursePage({ params }: CoursePageProps) {
  const { id } = await params
  return <CourseAnalytics courseId={id} />
}
