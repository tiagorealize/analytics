import ModuleDetails from '@/components/courses/ModuleDetails'

export default async function ModulePage({ 
  params 
}: { 
  params: Promise<{ id: string, moduleId: string }> 
}) {
  const resolvedParams = await params
  
  return <ModuleDetails courseId={resolvedParams.id} moduleId={resolvedParams.moduleId} />
}
