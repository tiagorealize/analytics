import UnitDetails from '@/components/courses/UnitDetails'

export default async function UnitPage({ 
  params 
}: { 
  params: Promise<{ id: string, moduleId: string, unitId: string }> 
}) {
  const resolvedParams = await params
  
  return <UnitDetails 
    courseId={resolvedParams.id} 
    moduleId={resolvedParams.moduleId} 
    unitId={resolvedParams.unitId} 
  />
}