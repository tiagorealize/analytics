# 🚨 INSTRUÇÕES CRÍTICAS PARA DEPLOY NO NETLIFY

## ❌ ERRO ATUAL
Você está fazendo upload apenas da pasta `build/` que contém arquivos já compilados. O Netlify precisa do **código fonte completo** para fazer o build.

## ✅ SOLUÇÃO CORRETA

### Opção 1: Upload do Projeto Completo
1. **Selecione TODA a pasta do projeto** (não apenas `build/`)
2. **Arraste a pasta inteira** para o Netlify
3. **Certifique-se** que contém:
   - `src/` (código fonte)
   - `package.json`
   - `next.config.js`
   - `netlify.toml`
   - `public/`

### Opção 2: Conectar Repositório Git
1. **Faça commit** de todos os arquivos no Git
2. **Conecte o repositório** ao Netlify
3. **Configure** as variáveis de ambiente

## 🔧 CONFIGURAÇÃO NO NETLIFY

### Build Settings
- **Build command**: `npm run build`
- **Publish directory**: `.next`
- **Node version**: `18`

### Variáveis de Ambiente (Opcionais)
```
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
NEXT_PUBLIC_GTM_ID=GTM-XXXXXXX
NEXT_PUBLIC_FB_PIXEL_ID=XXXXXXXXXXXXXXX
NEXT_PUBLIC_HOTJAR_ID=XXXXXXXXX
```

## 📁 ESTRUTURA CORRETA DO PROJETO

```
Dashboard/
├── src/
│   ├── app/
│   ├── components/
│   └── lib/
├── public/
├── package.json
├── next.config.js
├── netlify.toml
└── README.md
```

## ⚠️ NÃO FAÇA ISSO
- ❌ Upload apenas da pasta `build/`
- ❌ Upload apenas da pasta `.next/`
- ❌ Upload apenas dos arquivos compilados

## ✅ FAÇA ISSO
- ✅ Upload da pasta **raiz do projeto**
- ✅ Upload de **todos os arquivos fonte**
- ✅ Incluir `package.json` e `next.config.js`

## 🚀 DEPLOY RÁPIDO

1. **Zipe a pasta raiz** do projeto (Dashboard/)
2. **Faça upload** do arquivo ZIP no Netlify
3. **Configure** as variáveis de ambiente
4. **Deploy** deve funcionar!

---

**IMPORTANTE**: O Netlify precisa compilar o projeto, não usar arquivos já compilados!
