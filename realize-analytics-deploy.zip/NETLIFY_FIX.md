# 🚨 SOLUÇÃO PARA ERRO NO NETLIFY

## ❌ Problema Identificado:
O erro `"Couldn't find any pages or app directory"` acontece porque você está fazendo upload apenas da pasta `build` em vez do projeto completo.

## ✅ SOLUÇÃO CORRETA:

### Opção 1: Upload do Projeto Completo (Recomendado)
1. **Zipe toda a pasta do projeto** (não apenas a pasta build)
2. **Faça upload do arquivo ZIP** no Netlify
3. **Configure:**
   - Build command: `npm run build`
   - Publish directory: `.next`

### Opção 2: Deploy via Git (Melhor Prática)
1. **Faça push do projeto completo** para GitHub
2. **Conecte o repositório** ao Netlify
3. **Configure automaticamente:**
   - Build command: `npm run build`
   - Publish directory: `.next`

### Opção 3: Netlify CLI
```bash
# Na pasta raiz do projeto (não na pasta build)
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

## 🔧 Configuração Correta:

### netlify.toml (na raiz do projeto):
```toml
[build]
  command = "npm run build"
  publish = ".next"

[build.environment]
  NODE_VERSION = "18"
  NPM_VERSION = "9"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

### Estrutura de Arquivos Necessária:
```
projeto/
├── src/
│   ├── app/          ← ESSENCIAL: pasta app
│   ├── components/
│   └── lib/
├── public/
├── package.json
├── next.config.js
├── netlify.toml      ← na raiz
└── .next/           ← gerado após build
```

## 🚫 O QUE NÃO FUNCIONA:
- ❌ Upload apenas da pasta `build`
- ❌ Upload apenas da pasta `.next`
- ❌ Upload sem a pasta `src/app`

## ✅ O QUE FUNCIONA:
- ✅ Upload do projeto completo
- ✅ Deploy via Git
- ✅ Netlify CLI

## 📋 Checklist:
- [ ] Projeto completo com pasta `src/app`
- [ ] Arquivo `netlify.toml` na raiz
- [ ] Node.js 18+ configurado
- [ ] Build local funciona (`npm run build`)

---

**IMPORTANTE:** O Netlify precisa ter acesso à pasta `src/app` para fazer o build. A pasta `build` contém apenas os arquivos já compilados, mas não o código fonte necessário para o build.
