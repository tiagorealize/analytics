# Realize Analytics - Dashboard Educacional Inteligente

**Realize Analytics** é a plataforma de analytics educacional mais avançada para gestão de cursos, acompanhamento de alunos e insights de aprendizado. Transforme dados em decisões inteligentes com nossa solução completa de business intelligence educacional.

## 🎯 Sobre o Realize Analytics

Realize Analytics oferece uma visão 360° do ecossistema educacional, permitindo que instituições de ensino, empresas e educadores tomem decisões baseadas em dados reais. Nossa plataforma combina analytics avançados com uma interface intuitiva para maximizar o impacto educacional.

### 🌟 Principais Benefícios

- **📊 Analytics Inteligentes**: Insights detalhados sobre o desempenho educacional
- **🎓 Gestão Completa**: Acompanhe alunos, cursos e engajamento em tempo real
- **🔒 Segurança Avançada**: Proteção total dos dados educacionais
- **📱 Design Responsivo**: Acesso em qualquer dispositivo
- **⚡ Performance Otimizada**: Carregamento rápido e experiência fluida

## 🚀 Funcionalidades

### Visão Geral do Dashboard
- **Cards de KPIs**: Métricas principais com indicadores de tendência (Total de Alunos, Conclusão de Cursos, Taxa de Engajamento, Tempo Médio de Estudo)
- **Gráfico de Analytics**: Gráfico de linha interativo mostrando evolução temporal de engajamento, conclusão e tempo médio
- **Gráficos de Engajamento**: Gráficos de rosca para distribuição de engajamento por idade e dispositivo
- **Ranking de Cursos**: Cursos com melhor desempenho com taxas de conclusão e pontuações de satisfação
- **Insights Automáticos**: Recomendações e alertas baseados em IA

### Gestão de Cursos
- **Listagem de Cursos**: Visão abrangente de todos os cursos com capacidades de filtro
- **Métricas de Desempenho**: Taxas de conclusão, pontuações de satisfação, número de alunos e tempo médio
- **Filtros por Categoria**: Filtrar cursos por categoria (Frontend, Backend, Design, Data Science, Mobile)
- **Gestão de Status**: Acompanhar cursos ativos, inativos e rascunhos
- **Analytics Individuais**: Análise detalhada de desempenho do curso

### Analytics de Alunos
- **Tabela de Alunos**: Listagem completa de alunos com acompanhamento de progresso
- **Visualização de Progresso**: Barras de progresso visuais e percentuais de conclusão
- **Métricas de Engajamento**: Pontuações de engajamento individuais dos alunos
- **Progresso do Curso**: Acompanhar progresso do aluno em múltiplos cursos
- **Gestão de Status**: Monitorar alunos ativos, inativos e suspensos

### Relatórios e Exportação
- **Geração de Relatórios**: Criar relatórios abrangentes para diferentes períodos
- **Múltiplos Formatos**: Exportar em PDF, CSV e Excel
- **Exportação de Dados**: Exportar datasets específicos (cursos, alunos, métricas de engajamento)
- **Opções de Compartilhamento**: Gerar links públicos e enviar convites por email
- **Relatórios Recentes**: Acessar relatórios gerados anteriormente

## 🏢 Sobre a Empresa

**Realize Analytics** é uma empresa especializada em soluções de business intelligence para o setor educacional. Nossa missão é democratizar o acesso a insights educacionais avançados, permitindo que instituições de todos os tamanhos tomem decisões baseadas em dados.

### 📈 Nossa Visão
Ser a referência mundial em analytics educacional, transformando dados em oportunidades de aprendizado.

### 🎯 Nossa Missão
Fornecer ferramentas inteligentes que maximizem o impacto educacional através de insights baseados em dados.

### 🌐 Contato
- **Website**: [https://realize-analytics.com](https://realize-analytics.com)
- **Email**: contato@realize-analytics.com
- **LinkedIn**: [Realize Analytics](https://linkedin.com/company/realize-analytics)
- **Twitter**: [@realizeanalytics](https://twitter.com/realizeanalytics)

## 🛠️ Stack Tecnológico

- **Framework**: Next.js 14 com App Router
- **Linguagem**: TypeScript
- **Biblioteca de UI**: ShadCN UI com primitivos Radix UI
- **Estilização**: Tailwind CSS
- **Gráficos**: Recharts para visualização de dados
- **Ícones**: Lucide React
- **Gerenciamento de Estado**: React Context + useReducer
- **Manipulação de Datas**: API JavaScript Date nativa
- **SEO**: Otimizado para mecanismos de busca
- **Analytics**: Google Analytics, Facebook Pixel, Hotjar

## 📁 Estrutura do Projeto

```
dashboard/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── globals.css        # Estilos globais
│   │   ├── layout.tsx         # Layout raiz
│   │   ├── page.tsx          # Página inicial do dashboard
│   │   ├── courses/          # Páginas de cursos
│   │   ├── students/          # Páginas de alunos
│   │   └── reports/          # Páginas de relatórios
│   ├── components/            # Componentes React
│   │   ├── ui/               # Componentes ShadCN UI
│   │   ├── layout/           # Componentes de layout
│   │   ├── dashboard/        # Componentes específicos do dashboard
│   │   ├── courses/          # Componentes de gestão de cursos
│   │   ├── students/         # Componentes de gestão de alunos
│   │   └── reports/          # Componentes de relatórios
│   └── lib/                  # Utilitários e configurações
│       ├── utils.ts          # Funções utilitárias
│       ├── data.ts           # Dados mock
│       └── types.ts          # Tipos TypeScript
├── memory-bank/              # Documentação do projeto
└── public/                   # Assets estáticos
```

## 🚀 Como Começar

### Pré-requisitos
- Node.js 18+ 
- npm ou yarn

### Instalação

1. Clone o repositório:
```bash
git clone <url-do-repositorio>
cd dashboard
```

2. Instale as dependências:
```bash
npm install
```

3. Execute o servidor de desenvolvimento:
```bash
npm run dev
```

4. Abra [http://localhost:3000](http://localhost:3000) no seu navegador.

### Scripts Disponíveis

- `npm run dev` - Iniciar servidor de desenvolvimento
- `npm run build` - Build para produção
- `npm run start` - Iniciar servidor de produção
- `npm run lint` - Executar ESLint
- `npm run type-check` - Executar verificação de tipos TypeScript

## 🎨 Sistema de Design

O dashboard segue princípios de design moderno com:

- **Paleta de Cores**: Cores primárias azuis com neutros cinza
- **Tipografia**: Família de fontes Inter para legibilidade
- **Espaçamento**: Sistema de grid consistente de 4px
- **Componentes**: Componentes ShadCN UI com estilização personalizada
- **Design Responsivo**: Abordagem mobile-first com breakpoints Tailwind
- **Acessibilidade**: Componentes compatíveis com WCAG

## 📊 Estrutura de Dados

A aplicação usa dados mock abrangentes incluindo:

- **Cursos**: 5 cursos de exemplo com métricas de desempenho
- **Alunos**: 3 alunos de exemplo com acompanhamento de progresso
- **KPIs**: 4 indicadores-chave de desempenho com dados de tendência
- **Série Temporal**: 10 meses de dados históricos
- **Dados de Engajamento**: Distribuição por idade e dispositivo
- **Insights**: Recomendações e alertas automatizados

## 🔧 Personalização

### Adicionando Novas Métricas
1. Atualize a interface `KPIMetric` em `lib/types.ts`
2. Adicione dados a `mockKPIs` em `lib/data.ts`
3. Atualize o componente `KPICard` para lidar com novos tipos de métricas

### Adicionando Novos Tipos de Gráficos
1. Crie novos componentes de gráfico em `components/charts/`
2. Use componentes Recharts para visualização de dados
3. Siga o padrão existente para design responsivo

### Estendendo Modelos de Dados
1. Atualize interfaces TypeScript em `lib/types.ts`
2. Estenda dados mock em `lib/data.ts`
3. Atualize componentes para lidar com novos campos de dados

## 📱 Design Responsivo

O dashboard é totalmente responsivo com:
- **Mobile**: Sidebar recolhível, layouts empilhados
- **Tablet**: Layouts de grid otimizados, interações touch-friendly
- **Desktop**: Sidebar completa, layouts multi-coluna

## 🚀 Deploy e SEO

### Configuração de Analytics
Configure as seguintes variáveis de ambiente para analytics:

```bash
# Google Analytics 4
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX

# Google Tag Manager
NEXT_PUBLIC_GTM_ID=GTM-XXXXXXX

# Facebook Pixel
NEXT_PUBLIC_FB_PIXEL_ID=XXXXXXXXXXXXXXX

# Hotjar
NEXT_PUBLIC_HOTJAR_ID=XXXXXXXXX
```

### SEO Otimizado
- ✅ Meta tags otimizadas
- ✅ Open Graph para redes sociais
- ✅ Twitter Cards
- ✅ Sitemap.xml
- ✅ Robots.txt
- ✅ Manifest.json para PWA
- ✅ Schema.org markup
- ✅ Performance otimizada

### Deploy

#### Vercel (Recomendado)
1. Faça push do código para GitHub
2. Conecte o repositório ao Vercel
3. Configure as variáveis de ambiente
4. Deploy automático no push

#### Outras Plataformas
1. Execute `npm run build`
2. Deploy da pasta `.next` para sua plataforma de hospedagem
3. Configure variáveis de ambiente se necessário
4. Configure domínio personalizado

## 🤝 Contribuindo

1. Faça fork do repositório
2. Crie uma branch de feature
3. Faça suas alterações
4. Adicione testes se aplicável
5. Envie um pull request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT.

## 🆘 Suporte

Para suporte e dúvidas:
- Verifique a documentação em `memory-bank/`
- Revise os exemplos de componentes
- Abra uma issue para bugs ou solicitações de funcionalidades

---

**Realize Analytics** - Transformando dados educacionais em insights inteligentes

Construído com ❤️ usando Next.js, TypeScript e ShadCN UI

© 2024 Realize Analytics. Todos os direitos reservados.
