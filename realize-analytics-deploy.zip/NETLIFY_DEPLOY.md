# Realize Analytics - Deploy no Netlify

## 🚀 Configuração do Netlify

### 1. Configurações de Build
- **Build command:** `npm run build`
- **Publish directory:** `.next`
- **Node version:** 18.x

### 2. Variáveis de Ambiente (Opcional)
Configure no painel do Netlify:
```
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
NEXT_PUBLIC_GTM_ID=GTM-XXXXXXX
NEXT_PUBLIC_FB_PIXEL_ID=XXXXXXXXXXXXXXX
NEXT_PUBLIC_HOTJAR_ID=XXXXXXXXX
```

### 3. Arquivos de Configuração
- ✅ `netlify.toml` - Configuração principal
- ✅ `public/_redirects` - Redirecionamentos
- ✅ `next.config.js` - Configuração Next.js otimizada

## 🔧 Solução de Problemas Comuns

### Problema 1: Erro de Build
**Solução:** Verifique se o Node.js está na versão 18+
```bash
node --version
```

### Problema 2: Páginas não carregam
**Solução:** Verifique se o `_redirects` está na pasta `public/`

### Problema 3: Imagens não carregam
**Solução:** Configuração `unoptimized: true` no next.config.js

### Problema 4: Rotas dinâmicas não funcionam
**Solução:** Use o arquivo `_redirects` para capturar todas as rotas

## 📋 Checklist de Deploy

- [ ] Build local funciona (`npm run build`)
- [ ] Arquivo `netlify.toml` está na raiz
- [ ] Arquivo `_redirects` está em `public/`
- [ ] Node.js versão 18+ configurada
- [ ] Variáveis de ambiente configuradas (se necessário)
- [ ] Domínio personalizado configurado

## 🎯 URLs de Teste

Após o deploy, teste estas URLs:
- `/` - Dashboard principal
- `/login` - Página de login
- `/courses` - Lista de cursos
- `/students` - Lista de alunos
- `/courses/1` - Curso específico
- `/students/1` - Aluno específico

## 📞 Suporte

Se ainda houver problemas:
1. Verifique os logs de build no Netlify
2. Teste localmente primeiro
3. Verifique se todas as dependências estão instaladas
4. Confirme se o Node.js está na versão correta

---

**Status:** ✅ Pronto para deploy no Netlify
